package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Gamecreatorscoreboard extends AppCompatActivity {
    int []scores;
    String [] names;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamecreatorscoreboard);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");
        scores=getinfo.getIntArrayExtra("score");
        names=getinfo.getStringArrayExtra("names");

        TextView details=(TextView)findViewById(R.id.tw_scoreboardgamecreatordetails);
        Button back=(Button)findViewById(R.id.btn_backscoreboardgamecreator);
        ListView lw=(ListView)findViewById(R.id.lw_scoreboard_gamecreator);

        if (scores.length==0){
            details.setText("Your players have not completed any missons yet.");
        }

        CustomAdapter customAdapter=new CustomAdapter();
        lw.setAdapter(customAdapter);



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Gamecreatorscoreboard.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Gamecreatorscoreboard.this.startActivity(i);
            }
        });

    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return scores.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customscoreboard,null);
            TextView order=(TextView)convertView.findViewById(R.id.tw_scoresorder);
            TextView name=(TextView)convertView.findViewById(R.id.tw_namesscoreboard);
            TextView score=(TextView)convertView.findViewById(R.id.tw_scorescoreboard);
            order.setText((position+1)+".");
            name.setText(names[position]);
            score.setText(scores[position]+"");
            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
