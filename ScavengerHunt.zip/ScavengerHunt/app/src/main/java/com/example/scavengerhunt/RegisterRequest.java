package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;


public class RegisterRequest extends StringRequest {
    private Map<String,String> params;
    public RegisterRequest(String name,String lastname, String password, String email, int isAdmin,int isGameCreator,int isActive,String registerDate, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/register.php",listener,null);
        params=new HashMap<>();
        params.put("name",name);
        params.put("lastname",lastname);
        params.put("password",password);
        params.put("email",email);
        params.put("isAdmin",isAdmin + "");
        params.put("isGameCreator",isGameCreator + "");
        params.put("isActive",isActive + "");
        params.put("registerDate",registerDate);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
