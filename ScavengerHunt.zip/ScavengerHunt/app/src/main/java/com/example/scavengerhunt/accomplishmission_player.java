package com.example.scavengerhunt;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class accomplishmission_player extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private BeaconManager beaconManager;
    UUID beaconuuid=null;
    private Region ALL_ESTIMOTE_BEACONS;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;
    private TextView timer;

    private long mStartTimeInMillis;
    private long mTimeLeftInMillis;
    private long mEndTime;

    String beaconsuuid;
    int beaconmajor,beaconminor;
    LinearLayout layout_accomplish;

    ImageView iw_photo;
    Bitmap bitmap;
    int positions;
    Button takephoto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accomplishmission_player);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
            }
        }
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission)getinfo.getSerializableExtra("missionobject");
        final int beaconid[]=getinfo.getIntArrayExtra("beaconid");
        final String beaconname[]=getinfo.getStringArrayExtra("beaconname");
        final String uuid[]=getinfo.getStringArrayExtra("beaconuuid");
        final int major[]=getinfo.getIntArrayExtra("beaconmajor");
        final int minor[]=getinfo.getIntArrayExtra("beaconminor");



        String [] name=new String[beaconname.length+1];
        name[0]="Pick a Place";
        for (int i=0;i<beaconname.length;i++){
            name[i+1]=String.copyValueOf(beaconname[i].toCharArray());
        }

        timer=(TextView)findViewById(R.id.tw_minute);
        iw_photo=(ImageView)findViewById(R.id.iw_photo);
        takephoto=(Button)findViewById(R.id.btn_Take_photo);
        Button accomplish=(Button)findViewById(R.id.btn_accomplishmission);
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            takephoto.setEnabled(false);
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE},0);
        }



        TextView details=(TextView)findViewById(R.id.tw_missiondetails);
        Spinner beaconplaces=(Spinner)findViewById(R.id.selectbeaconsmission_spinner_accomplish);
        Button connectbeacon=(Button)findViewById(R.id.btn_chooseplace);
        final LinearLayout pickplace=(LinearLayout)findViewById(R.id.ll_pickplace);
        final LinearLayout layout_time=(LinearLayout)findViewById(R.id.ll_time);
        final LinearLayout layout_photo=(LinearLayout)findViewById(R.id.ll_photo);
        layout_accomplish=(LinearLayout)findViewById(R.id.ll_accomplish);
        Button gogame=(Button)findViewById(R.id.btn_backtogamepage_player);
        details.setText("\tMission Name:"+mission.mission_name[mission.position]+"\n Mission Description:"+mission.mission_description[mission.position]);
        layout_accomplish.setVisibility(View.INVISIBLE);

        final ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,name);
        beaconplaces.setAdapter(arrayAdapter);
        beaconplaces.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                positions=position;


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        connectbeacon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (positions==0){
                    Toast.makeText(getApplicationContext(),"Please pick a place",Toast.LENGTH_LONG).show();
                }else {
                    beaconsuuid = uuid[positions - 1];
                    beaconmajor = major[positions - 1];
                    beaconminor = minor[positions - 1];
                    beaconuuid = UUID.fromString(beaconsuuid);
                    beaconManager = new BeaconManager(getApplicationContext());
                    beaconManager.setBackgroundScanPeriod(10000, 10000);
                    beaconManager.setMonitoringListener(new BeaconManager.MonitoringListener() {
                        @Override
                        public void onEnteredRegion(Region region, List<Beacon> list) {
                            if (mission.mission_type[mission.position] == 1) {
                                layout_accomplish.setVisibility(View.VISIBLE);
                                pickplace.setVisibility(View.INVISIBLE);
                            } else if (mission.mission_type[mission.position] == 2) {
                                layout_time.setVisibility(View.VISIBLE);
                                pickplace.setVisibility(View.INVISIBLE);

                                long millis = Long.valueOf(mission.minute[mission.position]) * 60000;
                                setTime(millis);
                                startTimer();

                            } else if (mission.mission_type[mission.position] == 3) {
                                layout_photo.setVisibility(View.VISIBLE);
                                pickplace.setVisibility(View.INVISIBLE);
                            }
                            Toast.makeText(getApplicationContext(), "Beacon's connected", Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void onExitedRegion(Region region) {
                            if (mission.mission_type[mission.position] == 1) {
                                layout_accomplish.setVisibility(View.INVISIBLE);
                                pickplace.setVisibility(View.VISIBLE);
                            } else if (mission.mission_type[mission.position] == 2) {
                                layout_time.setVisibility(View.INVISIBLE);
                                pickplace.setVisibility(View.VISIBLE);
                                pauseTimer();
                            } else if (mission.mission_type[mission.position] == 3) {
                                layout_photo.setVisibility(View.INVISIBLE);
                                pickplace.setVisibility(View.VISIBLE);
                            }
                            layout_accomplish.setVisibility(View.INVISIBLE);

                            Toast.makeText(getApplicationContext(), "Beacon's connection failed", Toast.LENGTH_LONG).show();
                            beaconManager.disconnect();


                        }
                    });
                    beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
                        @Override
                        public void onServiceReady() {
                            ALL_ESTIMOTE_BEACONS = new Region("Monitoring regions", beaconuuid, beaconmajor, beaconminor);
                            beaconManager.startMonitoring(ALL_ESTIMOTE_BEACONS);
                        }
                    });


                }
            }
        });

        takephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photo=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(photo,102);

            }
        });
        accomplish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gid = game.gameid[game.gameposition];
                int mid = mission.mission_id[mission.position];
                int uid = user.id;
                String photo = "-1";
                if (mission.mission_type[mission.position] == 3) {
                    photo = imagetostring(bitmap);
                }
                if (mission.mission_type[mission.position] == 3 && photo.compareTo("-1")==0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(accomplishmission_player.this);
                    builder.setMessage("please upload a photo")
                            .setNegativeButton("Retry", null)
                            .create()
                            .show();
                } else {
                    Response.Listener<String> listener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                boolean success = jsonObject.getBoolean("success");
                                if (success) {
                                    beaconManager.disconnect();
                                    Intent gotogame = new Intent(accomplishmission_player.this, Ingame_player.class);
                                    gotogame.putExtra("userobject", user);
                                    gotogame.putExtra("gameobject", game);
                                    gotogame.putExtra("missionobject", mission);
                                    accomplishmission_player.this.startActivity(gotogame);

                                } else {
                                    String msg = jsonObject.getString("error");
                                    AlertDialog.Builder builder = new AlertDialog.Builder(accomplishmission_player.this);
                                    builder.setMessage(msg)
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    accomplishmissionRequest accomplishmission = new accomplishmissionRequest(gid, mid, uid, photo, listener);
                    RequestQueue queue = Volley.newRequestQueue(accomplishmission_player.this);
                    queue.add(accomplishmission);


                }
            }
        });
        gogame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotogame=new Intent(accomplishmission_player.this,Ingame_player.class);
                gotogame.putExtra("userobject",user);
                gotogame.putExtra("gameobject",game);
                gotogame.putExtra("missionobject",mission);
                accomplishmission_player.this.startActivity(gotogame);
            }
        });



    }
    private String imagetostring(Bitmap bitmap){
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
        byte[] imagebytes=outputStream.toByteArray();
        String encodedimage= Base64.encodeToString(imagebytes,Base64.DEFAULT);
        return  encodedimage;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle b=data.getExtras();
        assert b != null;
        bitmap=(Bitmap)b.get("data");
        iw_photo.setImageBitmap(bitmap);

    }

    private void setTime(long milliseconds) {
        mStartTimeInMillis = milliseconds;
        resetTimer();

    }
    private void startTimer() {
        mEndTime = System.currentTimeMillis() + mTimeLeftInMillis;

        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                updateWatchInterface();
            }
        }.start();

        mTimerRunning = true;
        updateWatchInterface();
    }

    private void resetTimer() {
        mTimeLeftInMillis = mStartTimeInMillis;
        updateCountDownText();
        updateWatchInterface();
    }
    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        updateWatchInterface();
    }
    private void updateCountDownText() {
        int hours = (int) (mTimeLeftInMillis / 1000) / 3600;
        int minutes = (int) ((mTimeLeftInMillis / 1000) % 3600) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;

        String timeLeftFormatted;
        if (hours > 0) {
            timeLeftFormatted = String.format(Locale.getDefault(),
                    "%d:%02d:%02d", hours, minutes, seconds);
        } else {
            timeLeftFormatted = String.format(Locale.getDefault(),
                    "%02d:%02d", minutes, seconds);
        }

        timer.setText(timeLeftFormatted);
    }
    private void updateWatchInterface() {
        if (mTimeLeftInMillis < 1000) {
            layout_accomplish.setVisibility(View.VISIBLE);
        } else {
            layout_accomplish.setVisibility(View.INVISIBLE);
        }
    }
    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putLong("startTimeInMillis", mStartTimeInMillis);
        editor.putLong("millisLeft", mTimeLeftInMillis);
        editor.putBoolean("timerRunning", mTimerRunning);
        editor.putLong("endTime", mEndTime);

        editor.apply();

        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
        }
    }
    @Override
    protected void onStart() {
        super.onStart();

        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);

        mStartTimeInMillis = prefs.getLong("startTimeInMillis", 600000);
        mTimeLeftInMillis = prefs.getLong("millisLeft", mStartTimeInMillis);
        mTimerRunning = prefs.getBoolean("timerRunning", false);

        updateCountDownText();
        updateWatchInterface();

        if (mTimerRunning) {
            mEndTime = prefs.getLong("endTime", 0);
            mTimeLeftInMillis = mEndTime - System.currentTimeMillis();

            if (mTimeLeftInMillis < 0) {
                mTimeLeftInMillis = 0;
                mTimerRunning = false;
                updateCountDownText();
                updateWatchInterface();
            } else {
                startTimer();
            }
        }
    }
    @Override
    protected void onDestroy() {
        beaconManager.disconnect();
        super.onDestroy();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION:
                if (grantResults.length>0 &&grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // TODO request success
                    takephoto.setEnabled(true);
                }
                break;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onBackPressed() {

    }
}
