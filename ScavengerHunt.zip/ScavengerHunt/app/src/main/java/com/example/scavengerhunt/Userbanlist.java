package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Userbanlist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userbanlist);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");
        final int [] userids=getinfo.getIntArrayExtra("userids");
        final String [] usernames=getinfo.getStringArrayExtra("usernames");

        Button home=(Button)findViewById(R.id.homeuserbanlist);

        ListView userlist=(ListView)findViewById(R.id.userlist_gc);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, usernames);
        userlist.setAdapter(adapter);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Userbanlist.this,Ingame_gamecreator.class);
                i.putExtra("userobject", user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Userbanlist.this.startActivity(i);
            }
        });
        userlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            boolean success=jsonObject.getBoolean("success");
                            if (success){
                                Intent gotobanlist=new Intent(Userbanlist.this,Usersettings.class);
                                gotobanlist.putExtra("userobject",user);
                                gotobanlist.putExtra("gameobject",game);
                                gotobanlist.putExtra("missionobject",mission);
                                Userbanlist.this.startActivity(gotobanlist);
                            }else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Userbanlist.this);
                                builder.setMessage("Something went wrong please try again")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                };
                BanplayerRequest banplayerRequest=new BanplayerRequest(game.gameid[game.gameposition],userids[position],listener);
                RequestQueue queue= Volley.newRequestQueue(Userbanlist.this);
                queue.add(banplayerRequest);

            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
