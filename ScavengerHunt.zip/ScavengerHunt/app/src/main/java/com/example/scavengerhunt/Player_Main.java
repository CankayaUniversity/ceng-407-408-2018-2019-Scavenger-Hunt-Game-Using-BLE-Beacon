package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Player_Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player__main);
        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");

        Button editprofile=(Button)findViewById(R.id.btn_editprofile_player);
        Button joingame=(Button) findViewById(R.id.btn_gotojoingame);
        Button gamelist=(Button)findViewById(R.id.btn_gamelist_player);
        Button logout=(Button)findViewById(R.id.btn_logout_player);

        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.id!=-1) {
                    Intent gotoeditprofile = new Intent(Player_Main.this, Edit_profile.class);
                    gotoeditprofile.putExtra("userobject", user);
                    gotoeditprofile.putExtra("gameobject", game);
                    gotoeditprofile.putExtra("missionobject",mission);
                    Player_Main.this.startActivity(gotoeditprofile);
                }

            }
        });
        joingame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.id!=-1) {
                    Intent gotojoingame = new Intent(Player_Main.this, joingame_player.class);
                    gotojoingame.putExtra("userobject", user);
                    gotojoingame.putExtra("gameobject", game);
                    gotojoingame.putExtra("missionobject",mission);
                    Player_Main.this.startActivity(gotojoingame);
                }
            }
        });
        gamelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (user.id != -1) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                JSONArray jsonArray = jsonObject.getJSONArray("games");
                                game.gamenames = new String[jsonArray.length()];
                                game.gameid = new int[jsonArray.length()];


                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject games = jsonArray.getJSONObject(i);
                                    game.gamenames[i] = games.getString("description");
                                    game.gameid[i] = games.getInt("id");

                                }
                                Intent gotogamelist = new Intent(Player_Main.this, gamelist_player.class);
                                gotogamelist.putExtra("userobject", user);
                                gotogamelist.putExtra("gameobject", game);
                                gotogamelist.putExtra("missionobject", mission);
                                Player_Main.this.startActivity(gotogamelist);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };
                Gamelist_playerRequest gamelist_playerRequest=new Gamelist_playerRequest(user.id,listener);
                RequestQueue queue=Volley.newRequestQueue(Player_Main.this);
                queue.add(gamelist_playerRequest);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.id=-1;
                user.name=null;
                user.surname=null;
                user.isGameCreator=-1;
                user.isActive=-1;
                user.pw=null;
                user.isAdmin=-1;
                Intent logout=new Intent(Player_Main.this,Loginpage.class);
                logout.putExtra("userobject", user);
                logout.putExtra("gameobject", game);
                logout.putExtra("missionobject",mission);
                Player_Main.this.startActivity(logout);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
