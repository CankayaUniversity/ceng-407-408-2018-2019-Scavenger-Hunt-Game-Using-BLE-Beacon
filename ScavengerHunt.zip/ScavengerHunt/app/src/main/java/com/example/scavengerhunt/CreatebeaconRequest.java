package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class CreatebeaconRequest extends StringRequest {
    private Map<String,String> params;
    public CreatebeaconRequest(int gameid, String placename, String UUID, int major, int minor, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/createbeacon.php",listener,null);
        params=new HashMap<>();
        params.put("gameid",gameid+"");
        params.put("placename",placename);
        params.put("UUID",UUID);
        params.put("major",major+"");
        params.put("minor",minor+"");

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
