package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

public class checkpictures_gamecreator extends AppCompatActivity {

    User user;
    Game game;
    Mission mission;
    int []mid;
    String[]photo;
    String[]usernames;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkpictures_gamecreator);
        Intent getinfo=getIntent();
        user=(User)getinfo.getSerializableExtra("userobject");
        game=(Game)getinfo.getSerializableExtra("gameobject");
        mission=(Mission) getinfo.getSerializableExtra("missionobject");
        photo=getinfo.getStringArrayExtra("photo");
        usernames=getinfo.getStringArrayExtra("usernames");
        mid=getinfo.getIntArrayExtra("missionid");

        Button home=(Button)findViewById(R.id.homepicturecheck);

        ListView pictures=(ListView)findViewById(R.id.lw_checkpictures);
        Customadapter customadapter=new Customadapter();
        pictures.setAdapter(customadapter);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(checkpictures_gamecreator.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                checkpictures_gamecreator.this.startActivity(i);
            }
        });
    }
    class Customadapter extends BaseAdapter{

        @Override
        public int getCount() {
            return photo.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customlistviewforpictures,null);
            imageView=(ImageView)convertView.findViewById(R.id.iw_pictureslist);
            TextView textView=(TextView)convertView.findViewById(R.id.tv_usernamelist);
            Button btn_confirm=(Button)convertView.findViewById(R.id.btn_confirmpicture);
            Button btn_denied=(Button)convertView.findViewById(R.id.btn_deniedpicture);
            String server="http://95.183.182.85:81/huntgame/";
            String url=server.concat(photo[position]);
            LoadImagefromURL(url);
            textView.setText("Player Name: "+usernames[position]);
            btn_confirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int id=mid[position];
                    int confirm=1;
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonRequest = new JSONObject(response);
                                boolean success=jsonRequest.getBoolean("success");
                                if (success){
                                    Intent gotomissionmenu=new Intent(checkpictures_gamecreator.this,missions.class);
                                    gotomissionmenu.putExtra("userobject",user);
                                    gotomissionmenu.putExtra("gameobject",game);
                                    gotomissionmenu.putExtra("missionobject",mission);
                                    checkpictures_gamecreator.this.startActivity(gotomissionmenu);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    pictureconfirmRequest pictureconfirm=new pictureconfirmRequest(id,confirm,listener);
                    RequestQueue queue= Volley.newRequestQueue(checkpictures_gamecreator.this);
                    queue.add(pictureconfirm);
                }
            });
            btn_denied.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int id=mid[position];
                    int confirm=0;
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonRequest = new JSONObject(response);
                                boolean success=jsonRequest.getBoolean("success");
                                if (success){
                                    Intent gotomissionmenu=new Intent(checkpictures_gamecreator.this,missions.class);
                                    gotomissionmenu.putExtra("userobject",user);
                                    gotomissionmenu.putExtra("gameobject",game);
                                    gotomissionmenu.putExtra("missionobject",mission);
                                    checkpictures_gamecreator.this.startActivity(gotomissionmenu);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    pictureconfirmRequest pictureconfirm=new pictureconfirmRequest(id,confirm,listener);
                    RequestQueue queue= Volley.newRequestQueue(checkpictures_gamecreator.this);
                    queue.add(pictureconfirm);

                }
            });

            return convertView;
        }
    }
    private void LoadImagefromURL(String url){
        Picasso.with(this).load(url).placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .into(imageView,new com.squareup.picasso.Callback(){

                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {

                    }
                });
    }
    @Override
    public void onBackPressed() {

    }
}
