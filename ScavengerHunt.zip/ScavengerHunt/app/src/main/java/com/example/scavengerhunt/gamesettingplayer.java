package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class gamesettingplayer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamesettingplayer);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission)getinfo.getSerializableExtra("missionobject");

        Button home=(Button)findViewById(R.id.btn_homegamesettingplayer);
        Button leave=(Button)findViewById(R.id.btn_leavegame);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(gamesettingplayer.this,Ingame_player.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                gamesettingplayer.this.startActivity(i);
            }
        });
        leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            boolean success=jsonObject.getBoolean("success");
                            if (success){
                                game.gameposition=-1;
                                Intent i=new Intent(gamesettingplayer.this,Player_Main.class);
                                i.putExtra("userobject",user);
                                i.putExtra("gameobject",game);
                                i.putExtra("missionobject",mission);
                                gamesettingplayer.this.startActivity(i);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                leavegameRequest leaverequest=new leavegameRequest(user.id,game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(gamesettingplayer.this);
                queue.add(leaverequest);
            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
