package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class gamelist_player extends AppCompatActivity {
    User user;
    Game game;
    Mission mission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamelist_player);
        Intent getinfo=getIntent();
        user=(User)getinfo.getSerializableExtra("userobject");
        game=(Game)getinfo.getSerializableExtra("gameobject");
        mission=(Mission)getinfo.getSerializableExtra("missionobject");

        Button home=(Button)findViewById(R.id.homegamelistplayer);
        ListView gamelist=(ListView)findViewById(R.id.lw_gamelist_player);

        CustomAdapter customAdapter=new CustomAdapter();
        gamelist.setAdapter(customAdapter);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoback=new Intent(gamelist_player.this,Player_Main.class);
                gotoback.putExtra("userobject",user);
                gotoback.putExtra("gameobject",game);
                gotoback.putExtra("missionobject",mission);
                gamelist_player.this.startActivity(gotoback);
            }
        });
    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return game.gameid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customlistviewforgame,null);
            final Button games=(Button)convertView.findViewById(R.id.listviewbutton);
            String name=(position+1)+"."+game.gamenames[position];
            games.setText(name);
            games.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    game.gameposition=position;
                    Intent gotoingame=new Intent(gamelist_player.this,Ingame_player.class);
                    gotoingame.putExtra("userobject",user);
                    gotoingame.putExtra("gameobject",game);
                    gotoingame.putExtra("missionobject",mission);
                    gamelist_player.this.startActivity(gotoingame);

                }
            });

            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
