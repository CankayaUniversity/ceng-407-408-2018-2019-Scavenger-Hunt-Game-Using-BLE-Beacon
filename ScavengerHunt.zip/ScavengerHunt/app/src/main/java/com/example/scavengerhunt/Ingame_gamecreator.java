package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Ingame_gamecreator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingame_gamecreator);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final String msg=getinfo.getStringExtra("stringinfo");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        Button mybeacons=(Button)findViewById(R.id.btn_mybeacons);
        Button code=(Button)findViewById(R.id.btn_code);
        Button invite=(Button)findViewById(R.id.btn_invite);
        Button btn_mission=(Button)findViewById(R.id.btn_gotomission);
        Button edit=(Button)findViewById(R.id.btn_gotoeditgame);
        Button usersetting=(Button)findViewById(R.id.btn_usersettings);
        Button scoreboard=(Button)findViewById(R.id.btn_scoreboard_gc);
        Button logout=(Button)findViewById(R.id.btn_logoutgame_gc);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Ingame_gamecreator.this,Gamecreator_main.class);
                i.putExtra("userobject", user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Ingame_gamecreator.this.startActivity(i);
            }
        });

        TextView gamename=(TextView)findViewById(R.id.gamename_gamecreator);

        gamename.setText(game.gamenames[game.gameposition].toUpperCase()+"\n Code: "+game.codes+"\n"+game.message);

        usersetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotousersetting=new Intent(Ingame_gamecreator.this,Usersettings.class);
                gotousersetting.putExtra("userobject",user);
                gotousersetting.putExtra("gameobject",game);
                gotousersetting.putExtra("missionobject",mission);

                Ingame_gamecreator.this.startActivity(gotousersetting);

            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoedit=new Intent(Ingame_gamecreator.this,gameedit_gamecreator.class);
                gotoedit.putExtra("userobject",user);
                gotoedit.putExtra("gameobject",game);
                gotoedit.putExtra("missionobject",mission);

                Ingame_gamecreator.this.startActivity(gotoedit);
            }
        });
        mybeacons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotobeacon=new Intent(Ingame_gamecreator.this,beacon_menu.class);
                gotobeacon.putExtra("userobject",user);
                gotobeacon.putExtra("gameobject",game);
                gotobeacon.putExtra("missionobject",mission);

                Ingame_gamecreator.this.startActivity(gotobeacon);
            }
        });
        btn_mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotomission=new Intent(Ingame_gamecreator.this,missions.class);
                gotomission.putExtra("userobject",user);
                gotomission.putExtra("gameobject",game);
                gotomission.putExtra("missionobject",mission);

                Ingame_gamecreator.this.startActivity(gotomission);

            }
        });
        code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotocode=new Intent(Ingame_gamecreator.this,Createcode_gamecreator.class);
                gotocode.putExtra("userobject",user);
                gotocode.putExtra("gameobject",game);
                gotocode.putExtra("missionobject",mission);

                Ingame_gamecreator.this.startActivity(gotocode);
            }
        });
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int active=1;
                int gc=0;
                int admin=0;
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("players");
                            int [] playerid=new int[jsonArray.length()];
                            String [] playername=new String[jsonArray.length()];
                            String [] playermail=new String[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject player=jsonArray.getJSONObject(i);
                                playerid[i]=player.getInt("playerid");
                                playername[i]=player.getString("playername");
                                playermail[i]=player.getString("playeremail");
                            }
                            Intent gotoinviteplayer=new Intent(Ingame_gamecreator.this,Send_invite.class);
                            gotoinviteplayer.putExtra("userobject",user);
                            gotoinviteplayer.putExtra("gameobject",game);
                            gotoinviteplayer.putExtra("playerid",playerid);
                            gotoinviteplayer.putExtra("playername",playername);
                            gotoinviteplayer.putExtra("playermail",playermail);
                            gotoinviteplayer.putExtra("missionobject",mission);
                            Ingame_gamecreator.this.startActivity(gotoinviteplayer);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                PlayerlistRequest playerlistRequest=new PlayerlistRequest(active,gc,admin,listener);
                RequestQueue queue= Volley.newRequestQueue(Ingame_gamecreator.this);
                queue.add(playerlistRequest);
            }
        });

        scoreboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("scoreboard");
                            int [] scores=new int[jsonArray.length()];
                            String [] names=new String[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject sc=jsonArray.getJSONObject(i);
                                scores[i]=sc.getInt("score");
                                names[i]=sc.getString("username");
                            }
                            Intent gotoscoreboard=new Intent(Ingame_gamecreator.this,Gamecreatorscoreboard.class);
                            gotoscoreboard.putExtra("userobject",user);
                            gotoscoreboard.putExtra("gameobject",game);
                            gotoscoreboard.putExtra("missionobject",mission);
                            gotoscoreboard.putExtra("score",scores);
                            gotoscoreboard.putExtra("names",names);
                            Ingame_gamecreator.this.startActivity(gotoscoreboard);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                GamecreatorscoreboardRequest request=new GamecreatorscoreboardRequest(game.gameid[game.gameposition],listener);
                RequestQueue queue=Volley.newRequestQueue(Ingame_gamecreator.this);
                queue.add(request);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
