package com.example.scavengerhunt;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.estimote.sdk.internal.utils.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class Mission_settings extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{
    int day,month,year,hour,minute;
    int finalday,finalmonth,finalyear,finalminute,finalhour;
    int startday=0,startmonth=0,startyear=0,startminute,starthour,endday=0,endmonth=0,endyear=0,endminute,endhour;
    String startdate=null;
    String enddate=null;
    TextView timedetails;
    int count=0;
    int countfirst=0;
    String [] beaconplace;
    int Tempbeaconid;
    boolean isstart;
    ArrayList<Integer> bids=new ArrayList<Integer>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_settings);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");
        final int [] beaconid=getinfo.getIntArrayExtra("beaconid");
        final String [] beaconname=getinfo.getStringArrayExtra("beaconname");
        final int [] misbeaconid=getinfo.getIntArrayExtra("misbeaconid");
        final String []misbeaconname=getinfo.getStringArrayExtra("misbeaconname");

        final LinearLayout showbeacon=(LinearLayout)findViewById(R.id.beacons_missionsettings);

        count=misbeaconid.length;
        beaconplace=new String[100];

        for(int i=0;i<misbeaconname.length;i++){
            final LinearLayout linearLayout=new LinearLayout(Mission_settings.this);
            Button button=new Button(Mission_settings.this);
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            button.setText(misbeaconname[i]);
            button.setId(i);
            bids.add(misbeaconid[i]);
            countfirst++;
            linearLayout.addView(button,params);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (countfirst<=0){
                        Toast.makeText(getApplicationContext(), "You need to add a beacon first", Toast.LENGTH_LONG).show();
                    }else {
                        int i = 0;
                        while (i < bids.size()) {
                            if (bids.get(i) == beaconid[v.getId()]) {
                                bids.remove(i);
                            }
                            i++;
                        }
                        linearLayout.removeView(v);
                        countfirst--;
                    }
                }
            });
            showbeacon.addView(linearLayout);

        }

        final EditText et_missionname=(EditText)findViewById(R.id.et_missionname_missionsettings);
        final EditText et_missiondesc=(EditText)findViewById(R.id.et_missiondescription_missionsettings);
        final EditText et_missionscore=(EditText)findViewById(R.id.et_missionscore_missionsettings);

        timedetails=(TextView)findViewById(R.id.tw_time_missionsettings);

        Button pickstart=(Button)findViewById(R.id.btn_pickstarttime_missionsettings);
        Button pickend=(Button)findViewById(R.id.btn_pickendtime_missionsettings);
        Button addbeaon=(Button)findViewById(R.id.btn_choosebeacons_missionsettings);
        Button update=(Button)findViewById(R.id.btn_missionupdate_missionsettings);
        Button delete=(Button)findViewById(R.id.btn_missiondelete_missionsettings);
        Button back=(Button)findViewById(R.id.btn_back_missionsettings);



        Spinner selectbeacon=(Spinner)findViewById(R.id.selectbeacons_spinner_missionsettings);

        et_missionname.setText(mission.mission_name[mission.position]);
        et_missiondesc.setText(mission.mission_description[mission.position]);
        et_missionscore.setText(mission.mission_score[mission.position]+"");

        timedetails.setText("Start Date: "+mission.mission_startdate[mission.position]+"Start Time"+mission.mission_starttime[mission.position]+"\n"+"End Date:"+mission.mission_enddate[mission.position]+"End Time:"+mission.mission_endtime[mission.position]);

        Calendar calendar=Calendar.getInstance();
        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH);
        day=calendar.get(Calendar.DAY_OF_MONTH);

        pickstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog start=new DatePickerDialog(Mission_settings.this,Mission_settings.this,year,month,day);
                start.show();
                isstart=true;
            }
        });
        pickend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(Mission_settings.this,Mission_settings.this,year,month,day);
                datePickerDialog.show();
                isstart=false;
            }
        });
        final ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,beaconname);
        selectbeacon.setAdapter(arrayAdapter);
        selectbeacon.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                beaconplace[countfirst]=arrayAdapter.getItem(position);
                Tempbeaconid =beaconid[position];
                //count++;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        addbeaon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (countfirst>=count){
                    Toast.makeText(getApplicationContext(), "You add all your beacon", Toast.LENGTH_LONG).show();
                }else {
                    countfirst++;
                    bids.add(Tempbeaconid);
                    final LinearLayout linearLayout = new LinearLayout(Mission_settings.this);
                    Button button = new Button(Mission_settings.this);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    button.setText(beaconplace[countfirst - 1]);
                    button.setId(countfirst - 1);
                    linearLayout.addView(button, params);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (countfirst <= 0) {
                                Toast.makeText(getApplicationContext(), "You need to add a beacon first", Toast.LENGTH_LONG).show();
                            } else {
                                int i = 0;

                                while (i < bids.size()) {
                                    if (bids.get(i) == beaconid[v.getId()]) {
                                        bids.remove(i);
                                    }
                                    i++;
                                }
                                linearLayout.removeView(v);
                                countfirst--;
                            }
                        }
                    });
                    showbeacon.addView(linearLayout);


                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=et_missionname.getText().toString().trim();
                String desc=et_missiondesc.getText().toString().trim();
                String sscore=et_missionscore.getText().toString().trim();
                int score=Integer.parseInt(et_missionscore.getText().toString());
                if (name.isEmpty()){
                    et_missionname.setError("Name can not be empty");
                }else if(desc.isEmpty()){
                    et_missiondesc.setError("Description can not be empty");
                }else if (sscore.isEmpty()){
                    et_missionscore.setError("Score can not be empty");
                }else if (score<=0){
                    et_missionscore.setError("Score can not be 0 or less");
                }else if (count<1){
                    Toast.makeText(getApplicationContext(),"Please enter pick at least a beacon",Toast.LENGTH_LONG).show();
                }else{
                    String enddate = "" + endday + "/" + endmonth + "/" + endyear;
                    String endtime = "" + endhour + ":" + endminute;
                    String startdate = ""+startday+"/"+startmonth+"/"+startyear;
                    String starttime = "" +starthour+":"+startminute;
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject=new JSONObject(response);
                                boolean success=jsonObject.getBoolean("success");
                                if (success){
                                    Intent i =new Intent(Mission_settings.this,Ingame_gamecreator.class);
                                    i.putExtra("userobject",user);
                                    i.putExtra("gameobject",game);
                                    i.putExtra("missionobject",mission);
                                    Mission_settings.this.startActivity(i);
                                }else{
                                    String msg=jsonObject.getString("info");
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Mission_settings.this);
                                    builder.setMessage(msg)
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    UpdatemissionRequest request=new UpdatemissionRequest(mission.mission_id[mission.position],name,desc,score,bids,enddate,endtime,startdate,starttime,listener);
                    RequestQueue queue= Volley.newRequestQueue(Mission_settings.this);
                    queue.add(request);
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            boolean success=jsonObject.getBoolean("success");
                            if (success){
                                Intent i =new Intent(Mission_settings.this,Ingame_gamecreator.class);
                                i.putExtra("userobject",user);
                                i.putExtra("gameobject",game);
                                i.putExtra("missionobject",mission);
                                Mission_settings.this.startActivity(i);
                            }else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Mission_settings.this);
                                builder.setMessage("Delete is failed")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                };
                MissiondeleteRequest delete=new MissiondeleteRequest(mission.mission_id[mission.position],listener);
                RequestQueue queue=Volley.newRequestQueue(Mission_settings.this);
                queue.add(delete);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(Mission_settings.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Mission_settings.this.startActivity(i);
            }
        });






    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        finalyear=year;
        finalmonth=month;
        finalday=dayOfMonth;

        Calendar calendar=Calendar.getInstance();
        hour=calendar.get(Calendar.HOUR_OF_DAY);
        minute=calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(Mission_settings.this,Mission_settings.this,hour,minute, DateFormat.is24HourFormat(this));
        timePickerDialog.show();
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        finalhour=hourOfDay;
        finalminute=minute;
        if (isstart==true){
            setstartdate(finalday,finalhour,finalminute,finalmonth,finalyear);
            startdate="Start Date: "+startday+"/"+startmonth+"/"+startyear+"\t Start Time: "+starthour+":"+startminute;
            timedetails.setText(startdate+"\n"+enddate);
        }else{
            setenddate(finalday,finalhour,finalminute,finalmonth,finalyear);
            enddate="End Date: "+endday+"/"+endmonth+"/"+endyear+"\t End Time: "+endhour+":"+endminute;
            timedetails.setText(startdate+"\n"+enddate);
        }
    }
    public void setstartdate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        startday=finalday;
        starthour=finalhour;
        startminute=finalminute;
        startmonth=finalmonth;
        startmonth=startmonth+1;
        startyear=finalyear;
    }
    public void setenddate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        endday=finalday;
        endhour=finalhour;
        endminute=finalminute;
        endmonth=finalmonth;
        endmonth=endmonth+1;
        endyear=finalyear;
    }
    @Override
    public void onBackPressed() {

    }
}
