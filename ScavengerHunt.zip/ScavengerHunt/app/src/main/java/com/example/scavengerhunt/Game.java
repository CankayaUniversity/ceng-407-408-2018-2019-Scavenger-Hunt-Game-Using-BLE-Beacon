package com.example.scavengerhunt;

import java.io.Serializable;

public class Game implements Serializable {

    String [] gamenames;
    int [] gameid;
    int gameposition;
    String codes;
    int codesid;
    String endtime;
    String enddate;
    String starttime;
    String startdate;
    int codesituation;
    String message;
}
