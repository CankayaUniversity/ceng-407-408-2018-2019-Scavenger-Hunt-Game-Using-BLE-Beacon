package com.example.scavengerhunt;

import java.io.Serializable;

public class User implements Serializable {
    String name;
    String surname;
    String pw;
    String email;
    String date;
    int isActive;
    int isAdmin;
    int isGameCreator;
    int id;
}
