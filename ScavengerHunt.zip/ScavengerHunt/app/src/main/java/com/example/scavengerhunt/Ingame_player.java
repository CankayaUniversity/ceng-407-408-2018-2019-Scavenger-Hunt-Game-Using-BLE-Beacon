package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Ingame_player extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingame_player);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission)getinfo.getSerializableExtra("missionobject");

        Button gotomissionlist=(Button)findViewById(R.id.btn_gotomission_player);
        Button scoreboard=(Button)findViewById(R.id.btn_scoreboard_player);
        TextView title=(TextView)findViewById(R.id.gametitleplayer);
        Button exit=(Button)findViewById(R.id.btn_outgame_player);
        title.setText(game.gamenames[game.gameposition].toUpperCase());
        Button setting=(Button)findViewById(R.id.btn_gamesettings_player);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                game.gameposition=-1;
                Intent exitgame=new Intent(Ingame_player.this,Player_Main.class);
                exitgame.putExtra("userobject",user);
                exitgame.putExtra("gameobject",game);
                exitgame.putExtra("missionobject",mission);
                Ingame_player.this.startActivity(exitgame);
            }
        });
        gotomissionlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("missions");
                            mission.mission_id=new int[jsonArray.length()];
                            mission.mission_name=new String[jsonArray.length()];
                            mission.mission_description=new String[jsonArray.length()];
                            mission.mission_type=new int[jsonArray.length()];
                            mission.mission_starttime=new String[jsonArray.length()];
                            mission.mission_startdate=new String[jsonArray.length()];
                            mission.mission_endtime=new String[jsonArray.length()];
                            mission.mission_enddate=new String[jsonArray.length()];
                            mission.mission_score=new int[jsonArray.length()];
                            mission.mission_done=new int[jsonArray.length()];
                            mission.isautocompare=new int[jsonArray.length()];
                            mission.minute=new int[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject missions=jsonArray.getJSONObject(i);
                                mission.mission_id[i]=missions.getInt("mission_id");
                                mission.mission_name[i]=missions.getString("mission_name");
                                mission.mission_description[i]=missions.getString("mission_description");
                                mission.mission_type[i]=missions.getInt("mission_type");
                                mission.mission_starttime[i]=missions.getString("mission_starttime");
                                mission.mission_startdate[i]=missions.getString("mission_startdate");
                                mission.mission_endtime[i]=missions.getString("mission_endtime");
                                mission.mission_enddate[i]=missions.getString("mission_enddate");
                                mission.mission_score[i]=missions.getInt("mission_score");
                                mission.mission_done[i]=missions.getInt("mission_done");
                                mission.isautocompare[i]=missions.getInt("isautocompare");
                                mission.minute[i]=missions.getInt("minu");

                            }
                            Intent gotomissionlist=new Intent(Ingame_player.this,missionlist_player.class);
                            gotomissionlist.putExtra("userobject",user);
                            gotomissionlist.putExtra("gameobject",game);
                            gotomissionlist.putExtra("missionobject",mission);
                            Ingame_player.this.startActivity(gotomissionlist);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                };
                MissionlistRequest_player missionlistRequest_player=new MissionlistRequest_player(user.id,game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(Ingame_player.this);
                queue.add(missionlistRequest_player);

            }
        });

        scoreboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            int myscore=jsonObject.getInt("personalscore");

                            JSONArray jsonArray=jsonObject.getJSONArray("scoreboard");

                            int [] scores=new int[jsonArray.length()];
                            String [] names=new String[jsonArray.length()];

                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject sc=jsonArray.getJSONObject(i);
                                scores[i]=sc.getInt("score");
                                names[i]=sc.getString("username");
                            }
                            Intent i=new Intent(Ingame_player.this,Playerscoreboard.class);
                            i.putExtra("userobject",user);
                            i.putExtra("gameobject",game);
                            i.putExtra("missionobject",mission);
                            i.putExtra("personalscore",myscore);
                            i.putExtra("names",names);
                            i.putExtra("scores",scores);
                            Ingame_player.this.startActivity(i);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                PlayerscoreboardRequest sc=new PlayerscoreboardRequest(user.id,game.gameid[game.gameposition],listener);
                RequestQueue queue=Volley.newRequestQueue(Ingame_player.this);
                queue.add(sc);
            }
        });
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Ingame_player.this,gamesettingplayer.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Ingame_player.this.startActivity(i);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
