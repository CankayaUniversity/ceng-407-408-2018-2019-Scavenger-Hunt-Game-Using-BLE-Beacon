package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class beacon_create extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beacon_create);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("useobject");
        final Game game=(Game) getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        final EditText place=(EditText)findViewById(R.id.beaconplace);
        final EditText uuid=(EditText)findViewById(R.id.beaconuuid);
        final EditText major=(EditText)findViewById(R.id.beaconmajor);
        final EditText minor=(EditText)findViewById(R.id.beaconminor);
        Button create=(Button)findViewById(R.id.btn_beaconcreate);
        Button home=(Button)findViewById(R.id.homecreatebeacon);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(beacon_create.this,Ingame_gamecreator.class);
                i.putExtra("useobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                beacon_create.this.startActivity(i);
            }
        });


        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String beaconsplace=place.getText().toString();
                final String beaconsuuid=uuid.getText().toString();
                final int beaconsmajor=Integer.parseInt(major.getText().toString());
                final int beaconsminor=Integer.parseInt(minor.getText().toString());
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success=jsonObject.getBoolean("success");
                            if (success){
                                Intent gotoingame=new Intent(beacon_create.this,Ingame_gamecreator.class);
                                gotoingame.putExtra("userobject",user);
                                gotoingame.putExtra("gameobject",game);
                                gotoingame.putExtra("missionobject",mission);

                                beacon_create.this.startActivity(gotoingame);
                            }else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(beacon_create.this);
                                builder.setMessage("Create Failed")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                CreatebeaconRequest createbeaconRequest=new CreatebeaconRequest(game.gameid[game.gameposition],beaconsplace,beaconsuuid,beaconsmajor,beaconsminor,listener);
                RequestQueue queue= Volley.newRequestQueue(beacon_create.this);
                queue.add(createbeaconRequest);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
