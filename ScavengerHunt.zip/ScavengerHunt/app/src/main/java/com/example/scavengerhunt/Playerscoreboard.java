package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Playerscoreboard extends AppCompatActivity {
    String [] names;
    int [] scores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playerscoreboard);

        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission)getinfo.getSerializableExtra("missionobject");
        final int personalscore=getinfo.getIntExtra("personalscore",0);
        names=getinfo.getStringArrayExtra("names");
        scores=getinfo.getIntArrayExtra("scores");

        TextView tw=(TextView)findViewById(R.id.tw_personalscore);
        ListView lw=(ListView)findViewById(R.id.lw_scoreboard_player);
        Button back=(Button)findViewById(R.id.btn_backscoreboardplayer);
        CustomAdapter customAdapter=new CustomAdapter();
        lw.setAdapter(customAdapter);
        if (personalscore==0){
            tw.setText("You don't have a score yet.");
        }else{
            tw.setText("Your score is "+personalscore);
        }
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotomission=new Intent(Playerscoreboard.this,Ingame_player.class);
                gotomission.putExtra("userobject",user);
                gotomission.putExtra("gameobject",game);
                gotomission.putExtra("missionobject",mission);
                Playerscoreboard.this.startActivity(gotomission);
            }
        });

    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return scores.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customscoreboard,null);

            TextView order=(TextView)convertView.findViewById(R.id.tw_scoresorder);
            TextView name=(TextView)convertView.findViewById(R.id.tw_namesscoreboard);
            TextView score=(TextView)convertView.findViewById(R.id.tw_scorescoreboard);
            order.setText((position+1)+".");
            name.setText(names[position]);
            score.setText(scores[position]+"");
            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
