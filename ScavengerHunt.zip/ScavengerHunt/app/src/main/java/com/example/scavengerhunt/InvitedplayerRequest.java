package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InvitedplayerRequest extends StringRequest {
    private Map<String,String> params;
    public InvitedplayerRequest(ArrayList<Integer>id, int gameid, int isactive, Response.Listener<String>listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/invitedplayer.php",listener,null);
        params=new HashMap<>();
        params.put("userid",""+id);
        params.put("gameid",""+gameid);
        params.put("isactive",""+isactive);

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
