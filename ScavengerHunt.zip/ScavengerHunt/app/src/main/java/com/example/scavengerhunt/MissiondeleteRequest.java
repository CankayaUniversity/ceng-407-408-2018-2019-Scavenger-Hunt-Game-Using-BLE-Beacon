package com.example.scavengerhunt;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MissiondeleteRequest extends StringRequest {
    private Map<String,String> params;
    public MissiondeleteRequest(int missionid, Response.Listener<String>listener){
        super(Request.Method.POST,"http://95.183.182.85:81/huntgame/missiondelete.php",listener,null);
        params=new HashMap<>();
        params.put("missionid",missionid+"");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
