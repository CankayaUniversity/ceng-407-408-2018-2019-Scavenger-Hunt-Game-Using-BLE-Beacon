package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class picturecheckmissions_gamecreator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picturecheckmissions_gamecreator);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");
        final String []missionname=getinfo.getStringArrayExtra("missionname");
        final int [] missionid=getinfo.getIntArrayExtra("missionid");

        Button home=(Button)findViewById(R.id.homepicturemissioncheck);

        ListView checkmissions=(ListView)findViewById(R.id.lw_picturesmissions);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, missionname);
        checkmissions.setAdapter(adapter);
        checkmissions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("pictures");
                            int []mid=new int[jsonArray.length()];
                            String []photo=new String[jsonArray.length()];
                            String[] usernames=new String[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject mis=jsonArray.getJSONObject(i);
                                usernames[i]=mis.getString("username");
                                mid[i]=mis.getInt("missionid");
                                photo[i]=mis.getString("photo");
                            }
                            Intent gotocheckpicturesmissions=new Intent(picturecheckmissions_gamecreator.this,checkpictures_gamecreator.class);
                            gotocheckpicturesmissions.putExtra("userobject",user);
                            gotocheckpicturesmissions.putExtra("gameobject",game);
                            gotocheckpicturesmissions.putExtra("missionid",mid);
                            gotocheckpicturesmissions.putExtra("photo",photo);
                            gotocheckpicturesmissions.putExtra("usernames",usernames);
                            gotocheckpicturesmissions.putExtra("missionobject",mission);
                            picturecheckmissions_gamecreator.this.startActivity(gotocheckpicturesmissions);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                };
                getpicturesRequest getpictures=new getpicturesRequest(missionid[position],listener);
                RequestQueue queue = Volley.newRequestQueue(picturecheckmissions_gamecreator.this);
                queue.add(getpictures);


            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotocheckpicturesmissions=new Intent(picturecheckmissions_gamecreator.this,Ingame_gamecreator.class);
                gotocheckpicturesmissions.putExtra("userobject",user);
                gotocheckpicturesmissions.putExtra("gameobject",game);
                gotocheckpicturesmissions.putExtra("missionobject",mission);
                picturecheckmissions_gamecreator.this.startActivity(gotocheckpicturesmissions);
            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
