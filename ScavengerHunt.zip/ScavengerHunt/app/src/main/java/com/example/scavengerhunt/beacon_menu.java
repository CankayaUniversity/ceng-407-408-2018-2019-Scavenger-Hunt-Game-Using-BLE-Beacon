package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class beacon_menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beacon_menu);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");




        Button home=(Button)findViewById(R.id.homebeaconmenu);
        Button beaconlist=(Button)findViewById(R.id.btn_listbeacon);
        Button createbeacon=(Button)findViewById(R.id.btn_createbeacon);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(beacon_menu.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                beacon_menu.this.startActivity(i);
            }
        });

        createbeacon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotocreatebeacon=new Intent(beacon_menu.this,beacon_create.class);
                gotocreatebeacon.putExtra("userobject",user);
                gotocreatebeacon.putExtra("gameobject",game);
                gotocreatebeacon.putExtra("missionobject",mission);
                beacon_menu.this.startActivity(gotocreatebeacon);
            }
        });


        beaconlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("Beacons");

                            int[] beaconid=new int[jsonArray.length()];
                            String []beaconname=new String[jsonArray.length()];
                            String [] beaconuuid=new String[jsonArray.length()];
                            int [] beaconmajor=new int[jsonArray.length()];
                            int [] beaconminor=new int[jsonArray.length()];

                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject beacon=jsonArray.getJSONObject(i);
                                beaconid[i]=beacon.getInt("Beaconid");
                                beaconname[i]=beacon.getString("Placename");
                                beaconuuid[i]=beacon.getString("UUID");
                                beaconmajor[i]=beacon.getInt("Major");
                                beaconminor[i]=beacon.getInt("Minor");
                            }


                            Intent gotobeaconlist=new Intent(beacon_menu.this,beacon_list.class);
                            gotobeaconlist.putExtra("userobject",user);
                            gotobeaconlist.putExtra("gameobject",game);
                            gotobeaconlist.putExtra("beaconid",beaconid);
                            gotobeaconlist.putExtra("beaconname",beaconname);
                            gotobeaconlist.putExtra("beaconuuid",beaconuuid);
                            gotobeaconlist.putExtra("beaconmajor",beaconmajor);
                            gotobeaconlist.putExtra("beaconminor",beaconminor);
                            gotobeaconlist.putExtra("missionobject",mission);
                            beacon_menu.this.startActivity(gotobeaconlist);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                BeaconlistRequest beaconlistRequest=new BeaconlistRequest(game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(beacon_menu.this);
                queue.add(beaconlistRequest);

            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
