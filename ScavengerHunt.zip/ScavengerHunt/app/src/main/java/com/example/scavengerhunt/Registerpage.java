package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Registerpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerpage);
        final EditText name=(EditText)findViewById(R.id.name_register);
        final EditText sname=(EditText)findViewById(R.id.surname_register);
        final EditText pw=(EditText)findViewById(R.id.password_register);
        final EditText email=(EditText)findViewById(R.id.email_register);
        final RadioButton player=(RadioButton) findViewById(R.id.playerradio_register);
        final RadioButton gcreator=(RadioButton)findViewById(R.id.gamecreatorradio_register);
        Button btn_goback=(Button)findViewById(R.id.btn_gotologin);
        Button register=(Button)findViewById(R.id.btn_register);
        final CheckBox agreement=(CheckBox)findViewById(R.id.useragreement);
        TextView infouseragreement=(TextView)findViewById(R.id.tw_useragreement);

        infouseragreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Registerpage.this);
                builder.setMessage("Please read these 'Terms of Use' carefully, before using the program.\n" +
                        "Users that are using this program are assumed to accept the following terms:\n" +
                        "\n" +
                        "1. RESPONSIBILITIES\n" +
                        "a) The developer team reserves the right to make changes to products and services at any time.\n" +
                        "b) The developer team provides the user's contractual services except technical failures which may make acceptance and commitment.\n" +
                        "c) The user agrees in advance that legal and criminal proceedings will be taken against the user, if the user will reverse engineer in the use of the program or take any further action to find or obtain the source code of the program.\n" +
                        "d) The user who use the application in activities within the game or in any part of the application and illegal, illegitimate, users who damage the third parties, misleading, offensive, obscene, pornographic, damaging personal rights, agree not to copyright, illegal activity and produce or share content. Otherwise, the user is fully responsible for the damage and the developer team may suspend or terminate such an account and reserve the right to start legal process. Therefore, the developer team reserves the right to share the information about the activity or user account to the judicial authorities.\n" +
                        "e) The users of the application are responsible for their relations with each other or with third parties.")
                        .setNegativeButton("OK", null)
                        .create()
                        .show();
            }
        });
        btn_goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotologin=new Intent(Registerpage.this,Loginpage.class);
                Registerpage.this.startActivity(gotologin);
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String rname = name.getText().toString();
                final String rsname = sname.getText().toString();
                final String rpw = pw.getText().toString();
                final String remail = email.getText().toString();
                SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
                String registerdate = date.format(new Date());
                int isActive = 1;
                int isAdmin = 0;
                int isGamecreator = 0;

                if (player.isChecked()) {
                    isAdmin = 0;
                } else if (gcreator.isChecked()) {
                    isAdmin = 0;
                    isGamecreator = 1;
                }
                if (rname.isEmpty()) {
                    name.setError("Name can not be empty");
                } else if (rname.length() < 2) {
                    name.setError("Name is invalid.");
                } else if (rsname.isEmpty()) {
                    sname.setError("Surname can not be empty");
                } else if (rsname.length() < 2) {
                    sname.setError("Surname is invalid.");
                } else if (rpw.length() < 4) {
                    pw.setError("Password must be at least 4 characters.");
                } else if (!agreement.isChecked()) {
                    Toast.makeText(getApplicationContext(), "Please accept the User Agreement.", Toast.LENGTH_LONG).show();
                } else if (!player.isChecked() && !gcreator.isChecked()) {
                    Toast.makeText(getApplicationContext(), "Please pick a role", Toast.LENGTH_LONG).show();
                } else if (remail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(remail).matches()) {
                    email.setError("Email is invalid");
                } else {

                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                boolean success = jsonObject.getBoolean("success");

                                if (success) {
                                    Intent intent = new Intent(Registerpage.this, Loginpage.class);
                                    Registerpage.this.startActivity(intent);
                                } else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Registerpage.this);
                                    builder.setMessage("Register Failed")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    RegisterRequest registerRequest = new RegisterRequest(rname, rsname, rpw, remail, isAdmin, isGamecreator, isActive, registerdate, responseListener);
                    RequestQueue queue = Volley.newRequestQueue(Registerpage.this);
                    queue.add(registerRequest);

                }
            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
