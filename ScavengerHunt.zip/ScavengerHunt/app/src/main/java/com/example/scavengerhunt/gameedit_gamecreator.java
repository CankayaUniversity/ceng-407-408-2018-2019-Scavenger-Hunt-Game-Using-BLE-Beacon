package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class gameedit_gamecreator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameedit_gamecreator);
        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");

        final EditText gamedesc=(EditText)findViewById(R.id.edittext_gamedescription_editgame);
        Button edit=(Button)findViewById(R.id.btn_updategame);
        Button delete=(Button)findViewById(R.id.btn_deletegame);
        Button back=(Button)findViewById(R.id.btn_back_gameedit);
        gamedesc.setText(game.gamenames[game.gameposition]);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoingame=new Intent(gameedit_gamecreator.this,Ingame_gamecreator.class);
                gotoingame.putExtra("userobject",user);
                gotoingame.putExtra("gameobject",game);
                gotoingame.putExtra("missionobject",mission);
                gameedit_gamecreator.this.startActivity(gotoingame);
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String description=gamedesc.getText().toString();
                int gameid=game.gameid[game.gameposition];
                if (description.isEmpty()){
                    gamedesc.setError("Game description can not be empty");
                }else {
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject=new JSONObject(response);
                                boolean success=jsonObject.getBoolean("success");
                                if (success){
                                    game.gamenames[game.gameposition]=description;
                                    Intent gotoingame=new Intent(gameedit_gamecreator.this,Ingame_gamecreator.class);
                                    gotoingame.putExtra("userobject",user);
                                    gotoingame.putExtra("gameobject",game);
                                    gotoingame.putExtra("missionobject",mission);
                                    gameedit_gamecreator.this.startActivity(gotoingame);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    GameupdateRequest gameupdateRequest=new GameupdateRequest(gameid,description,listener);
                    RequestQueue queue= Volley.newRequestQueue(gameedit_gamecreator.this);
                    queue.add(gameupdateRequest);

                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gameid=game.gameid[game.gameposition];
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            boolean success=jsonObject.getBoolean("success");
                            if (success){
                                Intent gotogamecreatormain=new Intent(gameedit_gamecreator.this,Gamecreator_main.class);
                                gotogamecreatormain.putExtra("userobject",user);
                                gotogamecreatormain.putExtra("gameobject",game);
                                gotogamecreatormain.putExtra("missionobject",mission);
                                gameedit_gamecreator.this.startActivity(gotogamecreatormain);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                GamedeleteRequest gamedeleteRequest=new GamedeleteRequest(gameid,listener);
                RequestQueue queue=Volley.newRequestQueue(gameedit_gamecreator.this);
                queue.add(gamedeleteRequest);

            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
