package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

public class beacon_list extends AppCompatActivity {
    User user;
    int[] beaconid;
    String[] beaconname;
    String[] beaconuuid;
    int[] beaconmajor;
    int[] beaconminor;
    Game game;
    Mission mission;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beacon_list);
        Intent getinfo=getIntent();
        user=(User)getinfo.getSerializableExtra("userobject");
        beaconid=getinfo.getIntArrayExtra("beaconid");
        beaconname=getinfo.getStringArrayExtra("beaconname");
        beaconuuid=getinfo.getStringArrayExtra("beaconuuid");
        beaconmajor=getinfo.getIntArrayExtra("beaconmajor");
        beaconminor=getinfo.getIntArrayExtra("beaconminor");
        game=(Game)getinfo.getSerializableExtra("gameobject");
        mission=(Mission) getinfo.getSerializableExtra("missionobject");
        ListView beaconslist=(ListView)findViewById(R.id.beaconlist);
        Button home=(Button)findViewById(R.id.homebeaconlist);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(beacon_list.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                beacon_list.this.startActivity(i);
            }
        });


        CustomAdapter customAdapter=new CustomAdapter();
        beaconslist.setAdapter(customAdapter);
        /*ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, beaconname);
        beaconslist.setAdapter(adapter);
        beaconslist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent gotobeaconset=new Intent(beacon_list.this,beacon_settings.class);
                gotobeaconset.putExtra("userobject",user);
                gotobeaconset.putExtra("beaconid",beaconid);
                gotobeaconset.putExtra("beaconname",beaconname);
                gotobeaconset.putExtra("beaconuuid",beaconuuid);
                gotobeaconset.putExtra("beaconmajor",beaconmajor);
                gotobeaconset.putExtra("beaconminor",beaconminor);
                gotobeaconset.putExtra("position",position);
                gotobeaconset.putExtra("gameobject",game);
                gotobeaconset.putExtra("missionobject",mission);
                beacon_list.this.startActivity(gotobeaconset);

            }
        });*/
    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return beaconid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customlistviewforgame,null);
            Button beacons=(Button)convertView.findViewById(R.id.listviewbutton);
            String name=(position+1)+"."+beaconname[position];
            beacons.setText(name);
            beacons.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent gotobeaconset=new Intent(beacon_list.this,beacon_settings.class);
                    gotobeaconset.putExtra("userobject",user);
                    gotobeaconset.putExtra("beaconid",beaconid);
                    gotobeaconset.putExtra("beaconname",beaconname);
                    gotobeaconset.putExtra("beaconuuid",beaconuuid);
                    gotobeaconset.putExtra("beaconmajor",beaconmajor);
                    gotobeaconset.putExtra("beaconminor",beaconminor);
                    gotobeaconset.putExtra("position",position);
                    gotobeaconset.putExtra("gameobject",game);
                    gotobeaconset.putExtra("missionobject",mission);
                    beacon_list.this.startActivity(gotobeaconset);

                }
            });

            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
