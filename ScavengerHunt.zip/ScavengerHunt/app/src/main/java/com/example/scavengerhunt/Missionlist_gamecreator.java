package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Missionlist_gamecreator extends AppCompatActivity {


    int [] Images={R.drawable.buttonred,R.drawable.fatbuttongreen,R.drawable.buttonyellow};
    String [] mission_name;
    int [] ismissiononline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missionlist_gamecreator);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");
        mission_name=new String[mission.mission_name.length];
        ismissiononline=new int[mission.ismissiononline.length];
        for (int i=0;i<mission_name.length;i++){
            mission_name[i]=mission.mission_name[i];
        }
        for (int i=0;i<ismissiononline.length;i++){
            ismissiononline[i]=mission.ismissiononline[i];
        }

        Button home=(Button)findViewById(R.id.btn_backfrommissionlist_gamecreator);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Missionlist_gamecreator.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Missionlist_gamecreator.this.startActivity(i);
            }
        });


        ListView lw=(ListView)findViewById(R.id.listviewmissionlist_gamecreator);
        CustomAdapter customAdapter=new CustomAdapter();
        lw.setAdapter(customAdapter);
        lw.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mission.position=position;
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("allbeacons");
                            int []beaconid=new int[jsonArray.length()];
                            String[] beaconname=new String[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject beacons=jsonArray.getJSONObject(i);
                                beaconid[i]=beacons.getInt("beaconid");
                                beaconname[i]=beacons.getString("placename");
                            }
                            JSONArray jsonArraybeaconmission=jsonObject.getJSONArray("missionbeacons");
                            int []missionbeaconid=new int[jsonArraybeaconmission.length()];
                            String[] beaconmissionname=new String[jsonArraybeaconmission.length()];
                            for (int i=0;i<jsonArraybeaconmission.length();i++){
                                JSONObject misbeacons=jsonArraybeaconmission.getJSONObject(i);
                                missionbeaconid[i]=misbeacons.getInt("beaconid");
                                beaconmissionname[i]=misbeacons.getString("placename");
                            }
                            Intent i=new Intent(Missionlist_gamecreator.this,Mission_settings.class);
                            i.putExtra("userobject",user);
                            i.putExtra("gameobject",game);
                            i.putExtra("missionobject",mission);
                            i.putExtra("beaconid",beaconid);
                            i.putExtra("beaconname",beaconname);
                            i.putExtra("misbeaconid",missionbeaconid);
                            i.putExtra("misbeaconname",beaconmissionname);
                            Missionlist_gamecreator.this.startActivity(i);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                Getbeaconmissionrequest getbeacons=new Getbeaconmissionrequest(mission.mission_id[mission.position],game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(Missionlist_gamecreator.this);
                queue.add(getbeacons);

            }
        });

    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return mission_name.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView =getLayoutInflater().inflate(R.layout.customlistviewformissionlist_gamecreator,null);
            ImageView iw=(ImageView)convertView.findViewById(R.id.imageView_missionlist_gamecreator);
            TextView tw=(TextView)convertView.findViewById(R.id.tw_missionlist_gamecreator);
            if (ismissiononline[position]==-1){
                iw.setImageResource(Images[0]);

            }else if(ismissiononline[position]==0){
                iw.setImageResource(Images[2]);
            }else{
                iw.setImageResource(Images[1]);
            }
            tw.setText(mission_name[position]);
            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
