package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class UpdatebeaconRequest extends StringRequest {
    private Map<String,String>params;
    public UpdatebeaconRequest(int beaconid, String place, String uuid, int major, int minor,int gameid, Response.Listener<String>listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/updatebeacon.php",listener,null);
        params=new HashMap<>();
        params.put("beaconid",beaconid + "");
        params.put("place",place);
        params.put("uuid",uuid);
        params.put("major",major + "");
        params.put("minor",minor + "");
        params.put("gameid",gameid + "");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
