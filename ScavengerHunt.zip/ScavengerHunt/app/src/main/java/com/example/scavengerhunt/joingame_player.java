package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class joingame_player extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joingame_player);

        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");

        final EditText code=(EditText)findViewById(R.id.joingamecode_edittext);
        Button joingame=(Button)findViewById(R.id.btn_joingame);
        Button back=(Button)findViewById(R.id.btn_backtoplayerfromjoingame);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoplayermain=new Intent(joingame_player.this,Player_Main.class);
                gotoplayermain.putExtra("userobject",user);
                gotoplayermain.putExtra("gameobject",game);
                gotoplayermain.putExtra("missionobject",mission);
                joingame_player.this.startActivity(gotoplayermain);
            }
        });
        joingame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String joincode=code.getText().toString();
                int situaiton=1;
                if (joincode.isEmpty()){
                    code.setError("join code can not be empty");
                }else if(joincode.length()<6){
                    code.setError("join code is invalid from length");
                }else {
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject=new JSONObject(response);
                                boolean success=jsonObject.getBoolean("success");
                                if (success){
                                    Intent gotoplayermain=new Intent(joingame_player.this,Player_Main.class);
                                    gotoplayermain.putExtra("userobject",user);
                                    gotoplayermain.putExtra("gameobject",game);
                                    gotoplayermain.putExtra("missionobject",mission);
                                    joingame_player.this.startActivity(gotoplayermain);
                                }else{
                                    String error=jsonObject.getString("error");
                                    AlertDialog.Builder builder = new AlertDialog.Builder(joingame_player.this);
                                    builder.setMessage(error)
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    joingameRequest joingameRequest=new joingameRequest(joincode,situaiton,user.id,listener);
                    RequestQueue queue = Volley.newRequestQueue(joingame_player.this);
                    queue.add(joingameRequest);

                }
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
