package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class CreatemissionRequest extends StringRequest {
    private Map<String,String> params;

    public CreatemissionRequest(int gameid, String missionname, String missiondescription, int missionscore,ArrayList<Integer> beaconid, int compare, int missionmin, String imagedata, String startdate, String starttime, String enddate, String endtime, int missiontype, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/createmission.php",listener,null);

        params=new HashMap<>();
        params.put("gameid",gameid+"");
        params.put("missionname",missionname);
        params.put("missiondescription",missiondescription);
        params.put("missionscore",missionscore+"");
        params.put("beaconid",beaconid+"");
        params.put("compare",compare+"");
        params.put("missionminute",missionmin+"");
        params.put("imagedata",imagedata);
        params.put("startdate",startdate);
        params.put("starttime",starttime);
        params.put("enddate",enddate);
        params.put("endtime",endtime);
        params.put("misiontype",missiontype+"");

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

