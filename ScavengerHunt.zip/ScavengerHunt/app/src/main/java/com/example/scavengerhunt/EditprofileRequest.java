package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class EditprofileRequest extends StringRequest {
    private Map<String,String> params;

    public EditprofileRequest(int id, String name,String surname,String pw,String email,String date,int isActive,int isAdmin,int isGamecreator, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/Editprofile.php",listener,null);
        params=new HashMap<>();
        params.put("id",id+"");
        params.put("name",name);
        params.put("surname",surname);
        params.put("pw",pw);
        params.put("email",email);
        params.put("date",date);
        params.put("isActive",isActive+"");
        params.put("isAdmin",isAdmin+"");
        params.put("isGamecreator",isGamecreator+"");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
