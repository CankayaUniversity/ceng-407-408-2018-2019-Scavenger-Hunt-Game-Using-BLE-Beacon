package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class CreatecodeRequest extends StringRequest {
    private Map<String,String>params;
    public CreatecodeRequest(int gameid, String code,String starttime,String startdate,String endtime,String enddate,int situation,Response.Listener<String>listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/createcode.php",listener,null);
        params=new HashMap<>();
        params.put("gameid",gameid+"");
        params.put("code",code);
        params.put("starttime",starttime);
        params.put("startdate",startdate);
        params.put("endtime",endtime);
        params.put("enddate",enddate);
        params.put("situation",situation+"");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
