package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class missions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missions);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        Button btngotopicturesmission=(Button)findViewById(R.id.btn_gotocheckpictures_missions);
        Button home=(Button)findViewById(R.id.homemissionspage);
        Button btngotocreatemission=(Button)findViewById(R.id.btn_gotocreatemission);
        Button btngotomissionlist=(Button)findViewById(R.id.btn_gotomissionlist_gamecreator);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(missions.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                missions.this.startActivity(i);
            }
        });
        btngotocreatemission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("Beacons");

                            int [] beaconid=new int[jsonArray.length()];
                            String []beaconname=new String[jsonArray.length()];

                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject beacon=jsonArray.getJSONObject(i);
                                beaconid[i]=beacon.getInt("Beaconid");
                                beaconname[i]=beacon.getString("Placename");
                            }
                            Intent gotocreatemission=new Intent(missions.this,createmission.class);
                            gotocreatemission.putExtra("userobject",user);
                            gotocreatemission.putExtra("gameobject",game);
                            gotocreatemission.putExtra("beaconid",beaconid);
                            gotocreatemission.putExtra("beaconname",beaconname);
                            gotocreatemission.putExtra("missionobject",mission);
                            missions.this.startActivity(gotocreatemission);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                BeaconlistRequest beaconlistRequest=new BeaconlistRequest(game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(missions.this);
                queue.add(beaconlistRequest);
            }
        });
        btngotopicturesmission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("missions");
                            int [] missionid=new int[jsonArray.length()];
                            String [] missionname=new String[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject mis=jsonArray.getJSONObject(i);
                                missionid[i]=mis.getInt("missionid");
                                missionname[i]=mis.getString("missionname");
                            }
                            Intent gotocheckpicturesmissions=new Intent(missions.this,picturecheckmissions_gamecreator.class);
                            gotocheckpicturesmissions.putExtra("userobject",user);
                            gotocheckpicturesmissions.putExtra("gameobject",game);
                            gotocheckpicturesmissions.putExtra("missionid",missionid);
                            gotocheckpicturesmissions.putExtra("missionname",missionname);
                            gotocheckpicturesmissions.putExtra("missionobject",mission);
                            missions.this.startActivity(gotocheckpicturesmissions);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                getpicturesmissionsRequest getpicturesmissions=new getpicturesmissionsRequest(game.gameid[game.gameposition],listener);
                RequestQueue queue=Volley.newRequestQueue(missions.this);
                queue.add(getpicturesmissions);
            }
        });
        btngotomissionlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("missions");
                            mission.mission_id=new int[jsonArray.length()];
                            mission.mission_name=new String[jsonArray.length()];
                            mission.mission_description=new String[jsonArray.length()];
                            mission.mission_type=new int[jsonArray.length()];
                            mission.mission_starttime=new String[jsonArray.length()];
                            mission.mission_startdate=new String[jsonArray.length()];
                            mission.mission_endtime=new String[jsonArray.length()];
                            mission.mission_enddate=new String[jsonArray.length()];
                            mission.mission_score=new int[jsonArray.length()];
                            mission.mission_done=new int[jsonArray.length()];
                            mission.isautocompare=new int[jsonArray.length()];
                            mission.minute=new int[jsonArray.length()];
                            mission.ismissiononline=new int[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject missions=jsonArray.getJSONObject(i);
                                mission.mission_id[i]=missions.getInt("mission_id");
                                mission.mission_name[i]=missions.getString("mission_name");
                                mission.mission_description[i]=missions.getString("mission_description");
                                mission.mission_type[i]=missions.getInt("mission_type");
                                mission.mission_starttime[i]=missions.getString("mission_starttime");
                                mission.mission_startdate[i]=missions.getString("mission_startdate");
                                mission.mission_endtime[i]=missions.getString("mission_endtime");
                                mission.mission_enddate[i]=missions.getString("mission_enddate");
                                mission.ismissiononline[i]=missions.getInt("ismissiononline");
                                mission.mission_score[i]=missions.getInt("mission_score");
                                mission.mission_done[i]=missions.getInt("mission_done");
                                mission.isautocompare[i]=missions.getInt("isautocompare");
                                mission.minute[i]=missions.getInt("minu");

                            }
                            Intent gotomissionlist=new Intent(missions.this,Missionlist_gamecreator.class);
                            gotomissionlist.putExtra("userobject",user);
                            gotomissionlist.putExtra("gameobject",game);
                            gotomissionlist.putExtra("missionobject",mission);
                            missions.this.startActivity(gotomissionlist);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                MissionlistRequest_gamecreator listrequest=new MissionlistRequest_gamecreator(game.gameid[game.gameposition],listener);
                RequestQueue queue=Volley.newRequestQueue(missions.this);
                queue.add(listrequest);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}
