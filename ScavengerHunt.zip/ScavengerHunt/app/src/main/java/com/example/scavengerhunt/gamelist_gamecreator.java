package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class gamelist_gamecreator extends AppCompatActivity {
    Game game;
    User user;
    Mission mission;
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamelist_gamecreator);
        Intent getuser=getIntent();
        user=(User)getuser.getSerializableExtra("userobject");
        game=(Game)getuser.getSerializableExtra("gameobject");
        mission=(Mission) getuser.getSerializableExtra("missionobject");
        ListView gamelist=(ListView)findViewById(R.id.gamelist_gc);

        Button back=(Button)findViewById(R.id.backgamelistgamecreator);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(gamelist_gamecreator.this,Gamecreator_main.class);
                i.putExtra("userobject", user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                gamelist_gamecreator.this.startActivity(i);
            }
        });


        CustomAdapter customAdapter=new CustomAdapter();
        gamelist.setAdapter(customAdapter);

    }
    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return game.gameid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.customlistviewforgame,null);
            Button games=(Button)convertView.findViewById(R.id.listviewbutton);
            String name=(position+1)+"."+game.gamenames[position];
            games.setText(name);

            games.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            game.gameposition=position;

                            try {
                                JSONObject jsonRequest = new JSONObject(response);
                                boolean success = jsonRequest.getBoolean("success");
                                if (success){
                                    game.message=jsonRequest.getString("info");
                                    game.codes=jsonRequest.getString("entrycode");
                                    game.codesid=jsonRequest.getInt("codeid");
                                    game.endtime=jsonRequest.getString("endtime");
                                    game.enddate=jsonRequest.getString("enddate");
                                    game.codesituation=jsonRequest.getInt("situation");
                                    game.startdate=jsonRequest.getString("startdate");
                                    game.starttime=jsonRequest.getString("starttime");
                                    Intent gotogame=new Intent(gamelist_gamecreator.this,Ingame_gamecreator.class);
                                    gotogame.putExtra("userobject",user);
                                    gotogame.putExtra("gameobject",game);
                                    gotogame.putExtra("missionobject",mission);
                                    gamelist_gamecreator.this.startActivity(gotogame);
                                }else {
                                    Toast.makeText(getApplicationContext(), "Something went wrong please try again", Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    };
                    GetcodesRequest getcodesRequest=new GetcodesRequest(game.gameid[game.gameposition],listener);
                    RequestQueue queue = Volley.newRequestQueue(gamelist_gamecreator.this);
                    queue.add(getcodesRequest);


                }
            });
            return convertView;
        }
    }
    @Override
    public void onBackPressed() {

    }
}
