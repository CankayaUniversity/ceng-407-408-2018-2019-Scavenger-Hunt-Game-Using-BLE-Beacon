package com.example.scavengerhunt;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import android.text.format.DateFormat;
//import android.icu.text.DateFormat;
//import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Createcode_gamecreator extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{

    int day,month,year,hour,minute;
    int finalday,finalmonth,finalyear,finalminute,finalhour;
    int startday,startmonth,startyear,startminute,starthour,endday,endmonth,endyear,endminute,endhour;
    String startdate=null;
    String enddate=null;
    boolean pickstart;
    TextView details;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createcode_gamecreator);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game) getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        final EditText code=(EditText)findViewById(R.id.createcode_edittext);
        Button random=(Button)findViewById(R.id.createrandomcode);
        Button create=(Button)findViewById(R.id.btn_createcode);
        Button picktime=(Button)findViewById(R.id.btn_picktime);
        Button pickstarttime=(Button)findViewById(R.id.btn_pickstarttime);
        details=(TextView)findViewById(R.id.timedetails_createcode);
        Button back=(Button)findViewById(R.id.btn_backcreatecode);

        Calendar calendar=Calendar.getInstance();
        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH);
        day=calendar.get(Calendar.DAY_OF_MONTH);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Createcode_gamecreator.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Createcode_gamecreator.this.startActivity(i);
            }
        });



        random.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String characters="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstvwxyz,.:_-<>#$+%&";
                String randomstring="";
                int length=6;
                Random rnd=new Random();
                char []text=new char[length];
                for (int i=0;i<length;i++){
                    text[i]=characters.charAt(rnd.nextInt(characters.length()));
                }
                for (int i=0;i<text.length;i++){
                    randomstring+=text[i];
                }
                code.setText(randomstring);
            }
        });
        pickstarttime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog start=new DatePickerDialog(Createcode_gamecreator.this,Createcode_gamecreator.this,year,month,day);
                start.show();
                pickstart=true;




            }
        });
        picktime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog datePickerDialog=new DatePickerDialog(Createcode_gamecreator.this,Createcode_gamecreator.this,year,month,day);
                datePickerDialog.show();
                pickstart=false;




            }
        });
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    final String gamecode = code.getText().toString();
                    String endcodedate = "" + endday + "/" + endmonth + "/" + endyear;
                    String endtime = "" + endhour + ":" + endminute;
                    String startcodedate = ""+startday+"/"+startmonth+"/"+startyear;
                    String starttime = "" +starthour+":"+startminute;
                    int situation = 1;

                    Response.Listener<String> listener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                boolean success = jsonObject.getBoolean("success");
                                if (success) {
                                    game.codesituation=1;
                                    game.message="Your code is up to date.";
                                    game.codes = gamecode;
                                    Intent gotoingame = new Intent(Createcode_gamecreator.this, Ingame_gamecreator.class);
                                    gotoingame.putExtra("userobject", user);
                                    gotoingame.putExtra("gameobject", game);
                                    gotoingame.putExtra("missionobject",mission);
                                    Createcode_gamecreator.this.startActivity(gotoingame);
                                } else {
                                    String msg=jsonObject.getString("error");
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Createcode_gamecreator.this);
                                    builder.setMessage(msg)
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    CreatecodeRequest createcodeRequest = new CreatecodeRequest(game.gameid[game.gameposition], gamecode,starttime,startcodedate, endtime, endcodedate, situation, listener);
                    RequestQueue queue = Volley.newRequestQueue(Createcode_gamecreator.this);
                    queue.add(createcodeRequest);


            }
        });

    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        finalyear=year;
        finalmonth=month;
        finalday=dayOfMonth;

        Calendar calendar=Calendar.getInstance();
        hour=calendar.get(Calendar.HOUR_OF_DAY);
        minute=calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(Createcode_gamecreator.this,Createcode_gamecreator.this,hour,minute,DateFormat.is24HourFormat(this));
        timePickerDialog.show();
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        finalhour=hourOfDay;
        finalminute=minute;
        if (pickstart==true){
            setstartdate(finalday,finalhour,finalminute,finalmonth,finalyear);
            startdate="Start Date: "+startday+"/"+startmonth+"/"+startyear+"\t Start Time: "+starthour+":"+startminute;
            details.setText(startdate+"\n"+enddate);
        }else{
            setenddate(finalday,finalhour,finalminute,finalmonth,finalyear);
            enddate="End Date: "+endday+"/"+endmonth+"/"+endyear+"\t End Time: "+endhour+":"+endminute;
            details.setText(startdate+"\n"+enddate);
        }

    }
    public void setstartdate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        startday=finalday;
        starthour=finalhour;
        startminute=finalminute;
        startmonth=finalmonth;
        startmonth=startmonth+1;
        startyear=finalyear;
    }
    public void setenddate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        endday=finalday;
        endhour=finalhour;
        endminute=finalminute;
        endmonth=finalmonth;
        endmonth=endmonth+1;
        endyear=finalyear;
    }
    @Override
    public void onBackPressed() {

    }
}
