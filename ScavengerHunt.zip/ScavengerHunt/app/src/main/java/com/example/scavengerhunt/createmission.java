package com.example.scavengerhunt;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.security.Permission;
import java.util.ArrayList;
import java.util.Calendar;

public class createmission extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{
    int count=0;
    int countcheck;
    int day,month,year,hour,minute;
    int finalday,finalmonth,finalyear,finalminute,finalhour;
    int startday=0,startmonth=0,startyear=0,startminute,starthour,endday=0,endmonth=0,endyear=0,endminute,endhour;
    String startdate=null;
    String enddate=null;
    int missiontype=-1;
    int autocompared=-1;
    LinearLayout timelayout,photolayout,samplephoto;
    ImageView sampleiw;
    int pickphoto=0;
    final int Code_gallery_request=999;
    Bitmap bitmap;
    int tempbeaconid;
    TextView timedetails;
    boolean isstart;

    int positions;
    EditText min_edittext;


    ArrayList<Integer> bids=new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createmission);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final int[] beaconid=getinfo.getIntArrayExtra("beaconid");
        final String[] beaconname=getinfo.getStringArrayExtra("beaconname");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");


        countcheck=beaconid.length;

        final String []beaconplaces=new String[beaconname.length];

        final LinearLayout pickedbeacon=(LinearLayout)findViewById(R.id.layout_selectedbeaconlist);
        timelayout=(LinearLayout)findViewById(R.id.choosetime);
        photolayout=(LinearLayout)findViewById(R.id.choosephoto_layout);
        samplephoto=(LinearLayout)findViewById(R.id.samplephoto);

        sampleiw=(ImageView)findViewById(R.id.sample_imageview);

        timedetails=(TextView)findViewById(R.id.tw_pickedtimes);
        Spinner selectbeacon=(Spinner)findViewById(R.id.selectbeacons_spinner);

        final EditText mname=(EditText)findViewById(R.id.missionname_edittext);
        final EditText mdesc=(EditText)findViewById(R.id.missiondescription_edittext);
        final EditText mscore=(EditText)findViewById(R.id.missionscore_edittext);
        min_edittext=(EditText)findViewById(R.id.minute_createmission);

        Button home=(Button)findViewById(R.id.homecreatemission);
        Button pstart=(Button)findViewById(R.id.btn_pickmissionstarttime);
        Button pend=(Button)findViewById(R.id.btn_pickmissionendtime);
        Button choosebeacon=(Button)findViewById(R.id.btn_choosebeacons);
        final Button stand=(Button)findViewById(R.id.btn_stand);
        final Button time=(Button)findViewById(R.id.btn_time);
        final Button photo=(Button)findViewById(R.id.btn_photo);
        Button choosephoto=(Button)findViewById(R.id.btn_choosephoto);
        final Button autocompare=(Button)findViewById(R.id.isautocompare);
        final Button notcompare=(Button)findViewById(R.id.btn_notcompare);
        final Button createmissionbtn=(Button)findViewById(R.id.btn_createmission);

        Calendar calendar=Calendar.getInstance();
        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH);
        day=calendar.get(Calendar.DAY_OF_MONTH);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(createmission.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                createmission.this.startActivity(i);
            }
        });

        pstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog start=new DatePickerDialog(createmission.this,createmission.this,year,month,day);
                start.show();
                isstart=true;
            }
        });

        pend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(createmission.this,createmission.this,year,month,day);
                datePickerDialog.show();
                isstart=false;
            }
        });
        final ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,beaconname);
        selectbeacon.setAdapter(arrayAdapter);

        selectbeacon.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                beaconplaces[position]=arrayAdapter.getItem(position);
                tempbeaconid =beaconid[position];
                positions=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        choosebeacon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (countcheck<count){
                    Toast.makeText(getApplicationContext(), "You add all your beacon", Toast.LENGTH_LONG).show();
                }else {

                    count++;
                    bids.add(tempbeaconid);
                    final LinearLayout linearLayout = new LinearLayout(createmission.this);
                    Button button = new Button(createmission.this);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    button.setText(beaconplaces[positions]);
                    button.setId(positions);
                    linearLayout.addView(button, params);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = 0;
                            linearLayout.removeView(v);
                            while (i < bids.size()) {
                                if (bids.get(i) == beaconid[v.getId()]) {
                                    bids.remove(i);
                                }
                                i++;
                            }
                            count--;
                        }
                    });
                    pickedbeacon.addView(linearLayout);
                }


            }
        });

        stand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                missiontype=1;
                timelayout.setVisibility(timelayout.INVISIBLE);
                photolayout.setVisibility(photolayout.INVISIBLE);
                samplephoto.setVisibility(samplephoto.INVISIBLE);
                stand.setTextColor(Color.RED);
                time.setTextColor(Color.BLACK);
                photo.setTextColor(Color.BLACK);
            }
        });
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                missiontype=2;
                timelayout.setVisibility(timelayout.VISIBLE);
                photolayout.setVisibility(photolayout.INVISIBLE);
                samplephoto.setVisibility(samplephoto.INVISIBLE);
                stand.setTextColor(Color.BLACK);
                time.setTextColor(Color.RED);
                photo.setTextColor(Color.BLACK);

            }
        });
        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                missiontype=3;
                timelayout.setVisibility(timelayout.INVISIBLE);
                photolayout.setVisibility(photolayout.VISIBLE);
                samplephoto.setVisibility(samplephoto.INVISIBLE);
                stand.setTextColor(Color.BLACK);
                time.setTextColor(Color.BLACK);
                photo.setTextColor(Color.RED);
            }
        });

        autocompare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autocompared=1;
                samplephoto.setVisibility(samplephoto.VISIBLE);
                autocompare.setTextColor(Color.RED);
                notcompare.setTextColor(Color.BLACK);
            }
        });
        notcompare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autocompared=0;
                pickphoto=0;
                samplephoto.setVisibility(samplephoto.INVISIBLE);
                autocompare.setTextColor(Color.BLACK);
                notcompare.setTextColor(Color.RED);
            }
        });
        choosephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(
                        createmission.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        Code_gallery_request
                );
            }
        });

        createmissionbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String misscore2=mscore.getText().toString().trim();
                String min2=min_edittext.getText().toString();


                int min=Integer.parseInt(min_edittext.getText().toString());
                String misname=mname.getText().toString().trim();
                String misdesc=mdesc.getText().toString().trim();
                int misscore=Integer.parseInt(mscore.getText().toString());

                int compare;
                int missionmin=0;
                String imagedata="-1";
                if (misname.isEmpty()){
                    mname.setError("Mission name can not be empty");
                }else if (misdesc.isEmpty()){
                    mdesc.setError("Mission description can not be empty");
                }else if (misscore<=0){
                    mscore.setError("mission score can not be zero or less ");
                }else if (misscore2.isEmpty()){
                    mscore.setError("mission score can not be empty");
                } else if (startyear==0 || startmonth==0 ||startday==0 ||endday==0 ||endmonth==0|| endyear==0){
                    Toast.makeText(getApplicationContext(),"Please pick start date and end date",Toast.LENGTH_LONG).show();
                }else if (count==0){
                    Toast.makeText(getApplicationContext(),"Please enter pick at least a beacon",Toast.LENGTH_LONG).show();
                }else if (missiontype==-1){
                    Toast.makeText(getApplicationContext(),"Please pick a mission type",Toast.LENGTH_LONG).show();
                }else if (missiontype==3 && autocompared==-1){
                    Toast.makeText(getApplicationContext(),"Please pick autocompared or not",Toast.LENGTH_LONG).show();
                }else if (missiontype==3 && autocompared==1 && pickphoto==0){
                    Toast.makeText(getApplicationContext(),"Please pick a sample photo for compare",Toast.LENGTH_LONG).show();
                }else if (missiontype==2 && min<=0){
                    min_edittext.setError("minute can not be zero or less");



                }else if(missiontype==2 && min2.isEmpty()){
                    min_edittext.setError("minute can not be empty");
                }
                else{

                    String enddate = "" + endday + "/" + endmonth + "/" + endyear;
                    String endtime = "" + endhour + ":" + endminute;
                    String startdate = ""+startday+"/"+startmonth+"/"+startyear;
                    String starttime = "" +starthour+":"+startminute;

                    missionmin=min;
                    int type=missiontype;
                    if (missiontype==3) {
                        compare = autocompared;
                        if (autocompared==1){
                            imagedata=imagetostring(bitmap);
                        }else{
                            imagedata="-1";
                        }
                    }else{
                        compare=0;
                    }

                    Response.Listener<String> listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject jsonRequest = new JSONObject(response);
                                boolean success = jsonRequest.getBoolean("success");
                                if (success){
                                    Intent gotoingame = new Intent(createmission.this, Ingame_gamecreator.class);
                                    gotoingame.putExtra("userobject", user);
                                    gotoingame.putExtra("gameobject", game);
                                    gotoingame.putExtra("missionobject", mission);
                                    createmission.this.startActivity(gotoingame);
                                }else {
                                    String msg=jsonRequest.getString("info");
                                    AlertDialog.Builder builder = new AlertDialog.Builder(createmission.this);
                                    builder.setMessage(msg)
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    CreatemissionRequest createmissionRequest=new CreatemissionRequest(game.gameid[game.gameposition],misname,misdesc,misscore,bids,compare,missionmin,imagedata,startdate,starttime,enddate,endtime,type,listener);
                    RequestQueue queue= Volley.newRequestQueue(createmission.this);
                    queue.add(createmissionRequest);


                }


            }
        });






    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode==Code_gallery_request){
            if (grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent,"Select image"),Code_gallery_request);
            }else {
                Toast.makeText(getApplicationContext(),"You don't have permission to access gallery",Toast.LENGTH_LONG).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode==Code_gallery_request && resultCode==RESULT_OK && data!=null){
            Uri filepath=data.getData();
            try {
                InputStream inputstream=getContentResolver().openInputStream(filepath);
                bitmap= BitmapFactory.decodeStream(inputstream);
                sampleiw.setImageBitmap(bitmap);
                pickphoto=1;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    private String imagetostring(Bitmap bitmap){
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
        byte[] imagebytes=outputStream.toByteArray();
        String encodedimage= Base64.encodeToString(imagebytes,Base64.DEFAULT);
        return  encodedimage;
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        finalyear=year;
        finalmonth=month;
        finalday=dayOfMonth;

        Calendar calendar=Calendar.getInstance();
        hour=calendar.get(Calendar.HOUR_OF_DAY);
        minute=calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(createmission.this,createmission.this,hour,minute, DateFormat.is24HourFormat(this));
        timePickerDialog.show();
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        finalhour=hourOfDay;
        finalminute=minute;
        if (isstart==true){
            setstartdate(finalday,finalhour,finalminute,finalmonth,finalyear);
            startdate="Start Date: "+startday+"/"+startmonth+"/"+startyear+"\t Start Time: "+starthour+":"+startminute;
            timedetails.setText(startdate+"\n"+enddate);
        }else{
            setenddate(finalday,finalhour,finalminute,finalmonth,finalyear);
            enddate="End Date: "+endday+"/"+endmonth+"/"+endyear+"\t End Time: "+endhour+":"+endminute;
            timedetails.setText(startdate+"\n"+enddate);
        }
    }
    public void setstartdate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        startday=finalday;
        starthour=finalhour;
        startminute=finalminute;
        startmonth=finalmonth;
        startmonth=startmonth+1;
        startyear=finalyear;
    }
    public void setenddate(int finalday ,int finalhour,int finalminute,int finalmonth,int finalyear ){
        endday=finalday;
        endhour=finalhour;
        endminute=finalminute;
        endmonth=finalmonth;
        endmonth=endmonth+1;
        endyear=finalyear;
    }
    @Override
    public void onBackPressed() {

    }

}
