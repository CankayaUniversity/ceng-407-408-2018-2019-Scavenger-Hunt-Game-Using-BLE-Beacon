package com.example.scavengerhunt;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UpdatemissionRequest extends StringRequest {
    private Map<String,String> params;
    public UpdatemissionRequest(int missionid,String name, String desc, int score, ArrayList<Integer> beacons,String enddate,String endtime,String startdate,String starttime, Response.Listener<String>listener){
        super(Request.Method.POST,"http://95.183.182.85:81/huntgame/missionupdate.php",listener,null);
        params=new HashMap<>();
        params.put("missionid",missionid+"");
        params.put("missionname",name);
        params.put("description",desc);
        params.put("score",score+"");
        params.put("beacons",beacons+ "");
        params.put("enddate",enddate);
        params.put("endtime",endtime);
        params.put("startdate",startdate);
        params.put("starttime",starttime);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
