package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CreateGamepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_gamepage);

        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");

        final EditText desc=(EditText)findViewById(R.id.description_creategame);
        Button btn_goback=(Button)findViewById(R.id.btngotogamecreatormain);

        Button btn_create=(Button)findViewById(R.id.btn_creategame);
        btn_goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back=new Intent(CreateGamepage.this,Gamecreator_main.class);
                back.putExtra("userobject", user);
                back.putExtra("gameobject",game);
                back.putExtra("missionobject",mission);
                CreateGamepage.this.startActivity(back);
            }
        });
        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String description = desc.getText().toString();
                final int id = user.id;
                if (description.isEmpty()) {
                    desc.setError("Game description can not be empty");
                } else {
                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss");
                    String createdate = date.format(new Date());
                    String currenttime = time.format(calendar.getTime());
                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                    Date onedaysafter = calendar.getTime();
                    String enddate = date.format(onedaysafter);
                    Response.Listener<String> stringListener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                boolean success = jsonObject.getBoolean("success");
                                if (success) {
                                    Intent successfulback = new Intent(CreateGamepage.this, Gamecreator_main.class);
                                    successfulback.putExtra("userobject", user);
                                    successfulback.putExtra("gameobject",game);
                                    successfulback.putExtra("missionobject",mission);
                                    CreateGamepage.this.startActivity(successfulback);
                                } else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(CreateGamepage.this);
                                    builder.setMessage("Create Failed")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    CreategameRequest creategameRequest = new CreategameRequest(description, id, createdate, currenttime, enddate, currenttime, stringListener);
                    RequestQueue queue = Volley.newRequestQueue(CreateGamepage.this);
                    queue.add(creategameRequest);
                }
            }
        });


    }
    @Override
    public void onBackPressed() {

    }
}
