package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class missionlist_player extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missionlist_player);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission)getinfo.getSerializableExtra("missionobject");

        Button home=(Button)findViewById(R.id.homemissionlstplayer);
        ListView missionlist=(ListView)findViewById(R.id.lw_missionlist_player);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, mission.mission_name);
        missionlist.setAdapter(adapter);
        missionlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mission.position=position;
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("beacons");
                            int[] beaconid=new int[jsonArray.length()];
                            String []beaconname=new String[jsonArray.length()];
                            String [] beaconuuid=new String[jsonArray.length()];
                            int [] beaconmajor=new int[jsonArray.length()];
                            int [] beaconminor=new int[jsonArray.length()];
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject beacon=jsonArray.getJSONObject(i);
                                beaconid[i]=beacon.getInt("beaconid");
                                beaconname[i]=beacon.getString("placename");
                                beaconuuid[i]=beacon.getString("uuid");
                                beaconmajor[i]=beacon.getInt("major");
                                beaconminor[i]=beacon.getInt("minor");
                            }
                                Intent gotomission=new Intent(missionlist_player.this,accomplishmission_player.class);
                                gotomission.putExtra("userobject",user);
                                gotomission.putExtra("gameobject",game);
                                gotomission.putExtra("missionobject",mission);
                                gotomission.putExtra("beaconid",beaconid);
                                gotomission.putExtra("beaconname",beaconname);
                                gotomission.putExtra("beaconuuid",beaconuuid);
                                gotomission.putExtra("beaconmajor",beaconmajor);
                                gotomission.putExtra("beaconminor",beaconminor);

                                missionlist_player.this.startActivity(gotomission);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                };
                getbeacons getbeacon=new getbeacons(mission.mission_id[mission.position],listener);
                RequestQueue queue = Volley.newRequestQueue(missionlist_player.this);
                queue.add(getbeacon);

            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotomission=new Intent(missionlist_player.this,Ingame_player.class);
                gotomission.putExtra("userobject",user);
                gotomission.putExtra("gameobject",game);
                gotomission.putExtra("missionobject",mission);
                missionlist_player.this.startActivity(gotomission);

            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
