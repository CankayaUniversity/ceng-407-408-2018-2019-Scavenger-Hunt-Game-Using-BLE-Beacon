package com.example.scavengerhunt;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class GetcodesRequest extends StringRequest {
    private Map<String,String> params;
    public GetcodesRequest(int gameid, Response.Listener<String> listener){
        super(Request.Method.POST,"http://95.183.182.85:81/huntgame/getcode.php",listener,null);
        params=new HashMap<>();
        params.put("gameid",gameid+"");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

