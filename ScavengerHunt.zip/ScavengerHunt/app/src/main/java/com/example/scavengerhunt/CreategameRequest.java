package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class CreategameRequest extends StringRequest {
    private Map<String,String> params;
    public CreategameRequest(String desc, int id,String startdate,String starttime,String enddate,String endtime, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/creategame.php",listener,null);
        params=new HashMap<>();
        params.put("description",desc);
        params.put("id",id+"");
        params.put("startdate",startdate);
        params.put("starttime",starttime);
        params.put("enddate",enddate);
        params.put("endtime",endtime);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
