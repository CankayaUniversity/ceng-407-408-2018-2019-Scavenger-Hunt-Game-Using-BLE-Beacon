package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class accomplishmissionRequest  extends StringRequest {
    private Map<String,String> params;
    public accomplishmissionRequest(int gameid,int missionid,int userid,String photo, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/accomplishmission.php",listener,null);
        params=new HashMap<>();
        params.put("gameid",gameid+"");
        params.put("missionid",missionid+"");
        params.put("userid",userid+"");
        params.put("photo",photo);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
