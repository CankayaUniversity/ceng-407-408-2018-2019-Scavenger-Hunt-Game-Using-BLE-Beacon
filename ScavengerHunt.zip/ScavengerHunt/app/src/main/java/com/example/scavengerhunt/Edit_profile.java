package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Edit_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");

        String role;
        if (user.isGameCreator==1){
            role="Game Creator";
        }else{
            role="Player";
        }



        Button save=(Button)findViewById(R.id.btn_save_editprofile_player);
        Button back=(Button)findViewById(R.id.btn_backtoplayer);
        TextView details=(TextView)findViewById(R.id.editprofile_details);
        final EditText name=(EditText)findViewById(R.id.name_editprofile_player);
        final EditText surname=(EditText)findViewById(R.id.surname_editprofile_player);
        final EditText newpw=(EditText)findViewById(R.id.password_editprofile_player_new);
        final EditText confirmpw=(EditText)findViewById(R.id.password_editprofile_player_confirm);
        final EditText email=(EditText)findViewById(R.id.email_editprofile_player);

        details.setText(role);
        name.setText(user.name,EditText.BufferType.EDITABLE);
        surname.setText(user.surname,EditText.BufferType.EDITABLE);
        email.setText(user.email,EditText.BufferType.EDITABLE);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.isGameCreator==1){
                    Intent gotoplayermain=new Intent(Edit_profile.this,Gamecreator_main.class);
                    gotoplayermain.putExtra("userobject",user);
                    gotoplayermain.putExtra("gameobject",game);
                    gotoplayermain.putExtra("missionobject",mission);
                    Edit_profile.this.startActivity(gotoplayermain);
                }else{
                    Intent gotoplayermain=new Intent(Edit_profile.this,Player_Main.class);
                    gotoplayermain.putExtra("userobject",user);
                    gotoplayermain.putExtra("gameobject",game);
                    gotoplayermain.putExtra("missionobject",mission);
                    Edit_profile.this.startActivity(gotoplayermain);
                }

            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String editname=name.getText().toString();
                final String editsurname=surname.getText().toString();
                final String editemail=email.getText().toString();
                final String editnewpw=newpw.getText().toString();
                String editconfirmpw=confirmpw.getText().toString();
                if (editname.isEmpty() || editname.length()<2){
                    name.setError("Name is invalid");
                }else if (editsurname.isEmpty() || editsurname.length()<2){
                    surname.setError("Surname is invalid");
                }else if (editemail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(editemail).matches()){
                    email.setError("Email is invalid");
                }else if (editnewpw.isEmpty() && editconfirmpw.isEmpty()){
                    Response.Listener<String>listener=new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject=new JSONObject(response);
                                boolean success=jsonObject.getBoolean("success");
                                if (success){
                                    user.name=editname;
                                    user.surname=editsurname;
                                    user.email=editemail;
                                    if (user.isGameCreator==1){
                                        Intent gotoplayermain=new Intent(Edit_profile.this,Gamecreator_main.class);
                                        gotoplayermain.putExtra("userobject",user);
                                        gotoplayermain.putExtra("gameobject",game);
                                        gotoplayermain.putExtra("missionobject",mission);
                                        Edit_profile.this.startActivity(gotoplayermain);
                                    }else{
                                        Intent gotoplayermain=new Intent(Edit_profile.this,Player_Main.class);
                                        gotoplayermain.putExtra("userobject",user);
                                        gotoplayermain.putExtra("gameobject",game);
                                        gotoplayermain.putExtra("missionobject",mission);
                                        Edit_profile.this.startActivity(gotoplayermain);
                                    }

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    };
                    EditprofileRequest editprofileRequest=new EditprofileRequest(user.id,editname,editsurname,user.pw,editemail,user.date,user.isActive,user.isAdmin,user.isGameCreator,listener);
                    RequestQueue queue= Volley.newRequestQueue(Edit_profile.this);
                    queue.add(editprofileRequest);


                }else {
                   if (editnewpw.isEmpty() || editconfirmpw.isEmpty() || editnewpw.compareTo(editconfirmpw)!=0 || editnewpw.length()<4){
                        newpw.setError("new password is invalid");
                    }else{
                        Response.Listener<String> stringListener=new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonObject=new JSONObject(response);
                                    boolean success=jsonObject.getBoolean("success");
                                    if (success){
                                        user.name=editname;
                                        user.surname=editsurname;
                                        user.email=editemail;
                                        user.pw=editnewpw;
                                        if (user.isGameCreator==1){
                                            Intent gotoplayermain=new Intent(Edit_profile.this,Gamecreator_main.class);
                                            gotoplayermain.putExtra("userobject",user);
                                            gotoplayermain.putExtra("gameobject",game);
                                            gotoplayermain.putExtra("missionobject",mission);
                                            Edit_profile.this.startActivity(gotoplayermain);
                                        }else{
                                            Intent gotoplayermain=new Intent(Edit_profile.this,Player_Main.class);
                                            gotoplayermain.putExtra("userobject",user);
                                            gotoplayermain.putExtra("gameobject",game);
                                            gotoplayermain.putExtra("missionobject",mission);
                                            Edit_profile.this.startActivity(gotoplayermain);
                                        }
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        };
                        EditprofileRequest editprofileRequest=new EditprofileRequest(user.id,editname,editsurname,editnewpw,editemail,user.date,user.isActive,user.isAdmin,user.isGameCreator,stringListener);
                        RequestQueue queue= Volley.newRequestQueue(Edit_profile.this);
                        queue.add(editprofileRequest);

                    }
                }
            }
        });


    }
    @Override
    public void onBackPressed() {

    }
}
