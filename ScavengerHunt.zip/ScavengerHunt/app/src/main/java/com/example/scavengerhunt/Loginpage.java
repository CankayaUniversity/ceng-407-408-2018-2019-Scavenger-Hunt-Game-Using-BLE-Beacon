package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Loginpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);
        final EditText email=(EditText)findViewById(R.id.email_loginpage);
        final EditText pw=(EditText)findViewById(R.id.pw_loginpage);
        Button login=(Button)findViewById(R.id.btn_login);
        TextView register=(TextView)findViewById(R.id.btn_gotoregister);
        final User user=new User();
        final Game game=new Game();
        final Mission mission=new Mission();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoregister =new Intent(Loginpage.this,Registerpage.class);
                Loginpage.this.startActivity(gotoregister);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email_login=email.getText().toString();
                final String pw_login=pw.getText().toString();
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonRequest = new JSONObject(response);
                            boolean success = jsonRequest.getBoolean("success");
                            if (success) {
                                user.id = jsonRequest.getInt("id");
                                user.name = jsonRequest.getString("name");
                                user.surname = jsonRequest.getString("surname");
                                user.email = jsonRequest.getString("email");
                                user.pw = jsonRequest.getString("password");
                                user.isActive = jsonRequest.getInt("isactive");
                                user.isAdmin = jsonRequest.getInt("isadmin");
                                user.isGameCreator = jsonRequest.getInt("isgamecreator");
                                user.date = jsonRequest.getString("date");
                                if (user.isActive == 0) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Loginpage.this);
                                    builder.setMessage("Your Account is not Active.")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                } else if (user.isGameCreator == 1) {
                                    Intent Gcreator = new Intent(Loginpage.this, Gamecreator_main.class);
                                    Gcreator.putExtra("userobject", user);
                                    Gcreator.putExtra("gameobject",game);
                                    Gcreator.putExtra("missionobject",mission);
                                    Loginpage.this.startActivity(Gcreator);
                                } else {
                                    Intent Player = new Intent(Loginpage.this, Player_Main.class);
                                    Player.putExtra("userobject", user);
                                    Player.putExtra("gameobject",game);
                                    Player.putExtra("missionobject",mission);
                                    Loginpage.this.startActivity(Player);
                                }

                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Loginpage.this);
                                builder.setMessage("Login is failed.")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                LoginRequest loginRequest = new LoginRequest(email_login, pw_login, responseListener);
                RequestQueue queue = Volley.newRequestQueue(Loginpage.this);
                queue.add(loginRequest);


            }
        });

    }
    @Override
    public void onBackPressed() {

    }
}
