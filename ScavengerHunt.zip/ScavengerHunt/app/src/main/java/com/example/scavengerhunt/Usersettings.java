package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Usersettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usersettings);
        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        Button userlist=(Button)findViewById(R.id.btn_gotouserlist);
        Button bannedlist=(Button)findViewById(R.id.btn_gotobannedlist);
        Button back=(Button)findViewById(R.id.homeusersettings);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Usersettings.this,Ingame_gamecreator.class);
                i.putExtra("userobject", user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Usersettings.this.startActivity(i);

            }
        });

        userlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("userinfo");
                            int [] userid=new int[jsonArray.length()];
                            String [] usernames=new String[jsonArray.length()];

                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject users=jsonArray.getJSONObject(i);
                                userid[i]=users.getInt("userid");
                                usernames[i]=users.getString("username");
                            }
                            Intent gotobanlist=new Intent(Usersettings.this,Userbanlist.class);
                            gotobanlist.putExtra("userobject",user);
                            gotobanlist.putExtra("gameobject",game);
                            gotobanlist.putExtra("userids",userid);
                            gotobanlist.putExtra("usernames",usernames);
                            gotobanlist.putExtra("missionobject",mission);
                            Usersettings.this.startActivity(gotobanlist);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                UserlistRequest userlistRequest=new UserlistRequest( game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(Usersettings.this);
                queue.add(userlistRequest);

            }
        });
        bannedlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("userinfo");
                            int [] userid=new int[jsonArray.length()];
                            String [] usernames=new String[jsonArray.length()];

                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject users=jsonArray.getJSONObject(i);
                                userid[i]=users.getInt("userid");
                                usernames[i]=users.getString("username");
                            }
                            Intent gotobanlist=new Intent(Usersettings.this,Userdebanlist.class);
                            gotobanlist.putExtra("userobject",user);
                            gotobanlist.putExtra("gameobject",game);
                            gotobanlist.putExtra("userids",userid);
                            gotobanlist.putExtra("usernames",usernames);
                            gotobanlist.putExtra("missionobject",mission);
                            Usersettings.this.startActivity(gotobanlist);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                userbannedlistRequest userlistRequest=new userbannedlistRequest( game.gameid[game.gameposition],listener);
                RequestQueue queue= Volley.newRequestQueue(Usersettings.this);
                queue.add(userlistRequest);

            }

        });

    }
    @Override
    public void onBackPressed() {

    }
}
