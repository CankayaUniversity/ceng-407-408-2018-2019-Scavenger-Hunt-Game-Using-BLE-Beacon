package com.example.scavengerhunt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Gamecreator_main extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamecreator_main);
        Intent getuser=getIntent();
        final User user=(User)getuser.getSerializableExtra("userobject");
        final Game game=(Game)getuser.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getuser.getSerializableExtra("missionobject");


        Button logout=(Button)findViewById(R.id.btn_logout_gamecreator);
        Button btn_creategame=(Button)findViewById(R.id.btn_gamecreate);
        Button btn_gamelist=(Button)findViewById(R.id.btn_gamelist_gamecreator);
        Button editprofile=(Button)findViewById(R.id.btn_editprofile_gamecreator);


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.name=null;
                user.surname=null;
                user.id=-1;
                user.isGameCreator=-1;
                user.isActive=-1;
                user.isAdmin=-1;
                user.email=null;
                user.pw=null;
                Intent i= new Intent(Gamecreator_main.this,Loginpage.class);
                i.putExtra("userobject", user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Gamecreator_main.this.startActivity(i);
            }
        });
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.isGameCreator==1) {
                    Intent gotoeditprofile = new Intent(Gamecreator_main.this, Edit_profile.class);
                    gotoeditprofile.putExtra("userobject", user);
                    gotoeditprofile.putExtra("gameobject",game);
                    gotoeditprofile.putExtra("missionobject",mission);
                    Gamecreator_main.this.startActivity(gotoeditprofile);
                }
            }
        });
        btn_creategame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.isGameCreator==1) {
                    Intent gotocreategame = new Intent(Gamecreator_main.this, CreateGamepage.class);
                    gotocreategame.putExtra("userobject", user);
                    gotocreategame.putExtra("gameobject",game);
                    gotocreategame.putExtra("missionobject",mission);
                    Gamecreator_main.this.startActivity(gotocreategame);
                }
            }
        });
        btn_gamelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.isGameCreator == 1) {
                    Response.Listener<String> listener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                JSONArray jsonArray = jsonObject.getJSONArray("games");
                                game.gamenames = new String[jsonArray.length()];
                                game.gameid = new int[jsonArray.length()];


                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject games = jsonArray.getJSONObject(i);
                                    game.gamenames[i] = games.getString("description");
                                    game.gameid[i] = games.getInt("id");

                                }
                                Intent gotogamelist = new Intent(Gamecreator_main.this, gamelist_gamecreator.class);
                                gotogamelist.putExtra("userobject", user);
                                gotogamelist.putExtra("gameobject", game);
                                gotogamelist.putExtra("missionobject", mission);
                                Gamecreator_main.this.startActivity(gotogamelist);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    GamelistRequest gamelistRequest = new GamelistRequest(user.id, listener);
                    RequestQueue queue = Volley.newRequestQueue(Gamecreator_main.this);
                    queue.add(gamelistRequest);

                }
            }
        });
    }

    @Override
    public void onBackPressed() {

    }
}
