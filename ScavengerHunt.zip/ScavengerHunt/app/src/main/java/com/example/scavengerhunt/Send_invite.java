package com.example.scavengerhunt;


import android.content.Intent;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Send_invite extends AppCompatActivity {
    int count=0;
    ArrayList<Integer>uid=new ArrayList<Integer>();
    ArrayList<String>umail=new ArrayList<String>();
    int positions;

    int countcheck;
    int isactive=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_invite);

        Intent getinfo=getIntent();
        final User user=(User)getinfo.getSerializableExtra("userobject");
        final Game game=(Game)getinfo.getSerializableExtra("gameobject");
        final Mission mission=(Mission) getinfo.getSerializableExtra("missionobject");

        final String [] playername=getinfo.getStringArrayExtra("playername");
        final int [] playerid=getinfo.getIntArrayExtra("playerid");
        final String [] playermail=getinfo.getStringArrayExtra("playermail");

        String [] players=new String[playername.length+1];
        players[0]="Pick a player";

        for(int i=0;i<playername.length;i++){
            players[i+1]=String.copyValueOf(playername[i].toCharArray());
        }


        countcheck=playerid.length;

        Button home=(Button)findViewById(R.id.homesendinvite);


        final LinearLayout invites=(LinearLayout)findViewById(R.id.layout_invitesplayer);
        Spinner spinner=(Spinner)findViewById(R.id.sendinvite_spinner);
        Button chooseinvite=(Button)findViewById(R.id.btn_chooseinvites);
        Button sendmail=(Button)findViewById(R.id.btn_sendinvites);

        final ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,players);
        spinner.setAdapter(arrayAdapter);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Send_invite.this,Ingame_gamecreator.class);
                i.putExtra("userobject",user);
                i.putExtra("gameobject",game);
                i.putExtra("missionobject",mission);
                Send_invite.this.startActivity(i);
            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                positions=position;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        chooseinvite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (positions == 0) {
                    Toast.makeText(getApplicationContext(), "Please pick a player", Toast.LENGTH_LONG).show();
                } else {
                    if (count > countcheck) {
                        Toast.makeText(getApplicationContext(), "You add all player", Toast.LENGTH_LONG).show();
                    } else {
                        count++;
                        umail.add(playermail[positions-1]);
                        uid.add(playerid[positions-1]);

                        final LinearLayout linearLayout = new LinearLayout(Send_invite.this);
                        final Button button = new Button(Send_invite.this);
                        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        button.setText(playername[positions - 1]);
                        button.setId(positions - 1);
                        linearLayout.addView(button, param);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (count <= 0) {
                                    Toast.makeText(getApplicationContext(), "you need to add one player first", Toast.LENGTH_LONG).show();
                                } else {
                                    int i = 0;
                                    while (i < uid.size()) {
                                        if (uid.get(i) == playerid[v.getId()]) {
                                            uid.remove(i);
                                            umail.remove(i);
                                        }
                                        i++;
                                    }
                                    count--;
                                    linearLayout.removeView(v);
                                }
                            }
                        });
                        invites.addView(linearLayout);
                    }
                }
            }
        });
        sendmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count == 0) {
                    Toast.makeText(getApplicationContext(), "Please pick at least one player", Toast.LENGTH_LONG).show();
                } else {
                    String subject = "You are invited to a game in Scavenger Hunt";
                    String msg = "You invited by " + user.name + "\n, Your Code: " + game.codes + "\n Scavenger Hunt Developer Team's Best Wishes";


                    for (int i = 0; i < umail.size(); i++) {
                        new Mail().sendEmail(umail.get(i), subject, msg);
                    }
                    Response.Listener<String> listener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {

                                JSONObject jsonObject = new JSONObject(response);
                                boolean success = jsonObject.getBoolean("success");
                                if (success) {
                                    Intent gotoingame = new Intent(Send_invite.this, Ingame_gamecreator.class);
                                    gotoingame.putExtra("userobject", user);
                                    gotoingame.putExtra("gameobject", game);
                                    gotoingame.putExtra("missionobject", mission);
                                    Send_invite.this.startActivity(gotoingame);
                                } else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Send_invite.this);
                                    builder.setMessage("Failed")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    InvitedplayerRequest invitedplayerRequest = new InvitedplayerRequest(uid, game.gameid[game.gameposition], isactive, listener);
                    RequestQueue queue = Volley.newRequestQueue(Send_invite.this);
                    queue.add(invitedplayerRequest);


                }
            }
        });
    }
    @Override
    public void onBackPressed() {

    }

}
