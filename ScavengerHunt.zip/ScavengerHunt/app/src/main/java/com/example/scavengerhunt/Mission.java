package com.example.scavengerhunt;

import java.io.Serializable;

public class Mission implements Serializable {
    int []mission_id;
    String [] mission_name;
    String [] mission_description;
    int []mission_type;
    String []mission_starttime;
    String []mission_startdate;
    String []mission_endtime;
    String []mission_enddate;
    int []mission_score;
    int []mission_done;
    int []isautocompare;
    int []minute;
    int position;
    int []ismissiononline;



}
