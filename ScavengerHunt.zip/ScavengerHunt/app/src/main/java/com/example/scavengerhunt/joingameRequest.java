package com.example.scavengerhunt;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class joingameRequest extends StringRequest {
    private Map<String,String> params;
    public joingameRequest(String code, int situation, int userid, Response.Listener<String> listener){
        super(Method.POST,"http://95.183.182.85:81/huntgame/joingame.php",listener,null);
        params=new HashMap<>();
        params.put("code",code);
        params.put("situation",situation+"");
        params.put("userid",userid+"");

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
