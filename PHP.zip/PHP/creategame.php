<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 18.03.2019
 * Time: 14:46
 */
    require_once 'Database.php';

    $description=$_POST["description"];
    $id=$_POST["id"];
    $startdate=$_POST["startdate"];
    $starttime=$_POST["starttime"];
    $enddate=$_POST["enddate"];
    $endtime=$_POST["endtime"];
    $situation=1;
    $gid=null;

    $response=array();
    function checkgame(){
        global $con,$id,$description;
        $statement=mysqli_prepare($con,"select * from game where def=? and userid=?");
        mysqli_stmt_bind_param($statement, "si", $description,$id);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        $count=mysqli_stmt_num_rows($statement);
        if($count<1){
            return true;
        }else{
            return false;

        }
    }
    function creategame()
    {
        global $con, $response, $description, $id;
        $statement = mysqli_prepare($con, "insert into game(def,userid) values(?,?)");
        mysqli_stmt_bind_param($statement, "si", $description, $id);
        mysqli_stmt_execute($statement);
        $response["success"] = true;

    }
    function getgame(){
        global $con, $description, $id,$gid;
        $statement = mysqli_prepare($con, "select gameid from game where def=? and userid=?");
        mysqli_stmt_bind_param($statement, "si", $description, $id);
        mysqli_stmt_execute($statement);

        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $gameid);


        while (mysqli_stmt_fetch($statement)) {
            $gid=$gameid;

        }

    }
    function generateRandomString() {
        $length = 6;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    function createcode(){
        global $con,$startdate,$endtime,$starttime,$enddate,$situation,$gid;
        $code=generateRandomString();
        $statement=mysqli_prepare($con,"insert into codes(gameid,entrycode,starttime,Startdate,endtime,Enddate,situation) values (?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($statement,"isssssi",$gid,$code,$starttime,$startdate,$endtime,$enddate,$situation);
        mysqli_stmt_execute($statement);
    }
    if (checkgame()){
        creategame();
        getgame();
        createcode();

    }else{
        $response["success"]=false;
        $response["error"]="You have this game already";
    }






    echo json_encode($response);
    mysqli_close($con);

?>