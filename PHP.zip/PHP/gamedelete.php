<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 6.05.2019
 * Time: 12:42
 */
require_once 'Database.php';
$response=array();
$gid=$_POST["gameid"];
function Deletegame()
{
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM game WHERE gameid= ".$gid." ");
    mysqli_stmt_execute($statement);
}
function Deleteinvitedplayer(){
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM invitedplayer WHERE gameid= ".$gid." ");
    mysqli_stmt_execute($statement);
}
function Deletemission(){
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM missions WHERE game_id= ".$gid." ");
    mysqli_stmt_execute($statement);
}
function Deletecode(){
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM codes WHERE gameid= ".$gid." ");
    mysqli_stmt_execute($statement);
}
function Deletebeacons(){
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM beacons WHERE Gameid= ".$gid." ");
    mysqli_stmt_execute($statement);
}
function Deleteaccomplishmission(){
    global $con,$gid;
    $statement = mysqli_query($con, "DELETE FROM accomplishmission WHERE gameid=".$gid." ");
    mysqli_stmt_execute($statement);
}
if ($gid==null){
    $response["success"]=false;
}else{
    Deletegame();
    Deleteinvitedplayer();
    Deletemission();
    Deletecode();
    Deletebeacons();
    Deleteaccomplishmission();
    $response["success"]=true;
}
echo json_encode($response);
?>