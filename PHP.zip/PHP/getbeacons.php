<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 29.04.2019
 * Time: 11:34
 */

require_once 'Database.php';

$missionid=$_POST["missionid"];
$beaconids=array();
$beacondef=array();
$beacons=array();


function getbeaconids(){
    global $con,$beaconids,$missionid;
    $count=0;
    $statement=mysqli_prepare($con,"select * from beaconmission where mission_id=?");
    mysqli_stmt_bind_param($statement,"i",$missionid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $beaconmission_id, $beacon_id, $mission_id);
    while (mysqli_stmt_fetch($statement)) {
        $beaconids[$count]=$beacon_id;
        $count++;
    }

}
function getbeacons(){
    global $con,$beaconids,$beacondef;
    $count=0;
    foreach ($beaconids as $id){
        $statement=mysqli_prepare($con,"select * from beacons where Beaconid=?");
        mysqli_stmt_bind_param($statement,"i",$id);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $Beaconid, $Gameid, $Placename,$UUID,$Major,$Minor);
        while (mysqli_stmt_fetch($statement)) {
            $beacondef[$count]["beaconid"]=$Beaconid;
            $beacondef[$count]["placename"]=$Placename;
            $beacondef[$count]["uuid"]=$UUID;
            $beacondef[$count]["major"]=$Major;
            $beacondef[$count]["minor"]=$Minor;

            $count++;
        }

    }
}
getbeaconids();
getbeacons();
$beacons["beacons"]=$beacondef;
echo json_encode($beacons);
?>