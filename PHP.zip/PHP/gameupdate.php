<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 6.05.2019
 * Time: 12:36
 */

require_once 'Database.php';
$response=array();
$gid=$_POST["gameid"];
$gdesc=$_POST["description"];

function updategame(){
    global $con,$gid,$gdesc,$response;
    $statement = mysqli_query($con, "UPDATE game SET def='".$gdesc."' WHERE gameid=".$gid." ");
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}
if ($gid==null || $gdesc==null){
    $response["success"]=false;
}else{
    updategame();
}
echo json_encode($response);
?>