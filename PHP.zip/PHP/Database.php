<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 6.03.2019
 * Time: 18:01
 */
$host="localhost:3306";
$user="icoinspr_akseli";
$pass="1nk@o7w,S5jA";
$database="icoinspr_huntgame";
    $con=mysqli_connect($host,$user,$pass,$database);
    mysqli_query($con,"SET NAMES utf8");
    mysqli_query($con, "SET CHARACTER SET utf8_turkish_ci");
?>