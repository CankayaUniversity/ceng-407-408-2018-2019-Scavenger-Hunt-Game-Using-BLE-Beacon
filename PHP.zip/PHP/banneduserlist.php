<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 14.05.2019
 * Time: 12:18
 */
require_once 'Database.php';
$gid=$_POST["gameid"];
$codeids=null;
$uids=array();
$unames=array();
$response=array();
$userinfo=array();

function Take_codeids(){
    global $con,$gid,$codeids;
    $statement = mysqli_prepare($con, "select * from codes where gameid=?");
    mysqli_stmt_bind_param($statement, "i", $gid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $codeid, $gameid, $entrycode, $starttime, $Startdate, $endtime, $Enddate,$situation);

    while (mysqli_stmt_fetch($statement)) {
        $codeids=$codeid;
    }
}
function Take_userids(){
    global $con,$codeids,$uids;
    $count=0;
    $sit=0;
    $statement = mysqli_prepare($con, "select * from joingame where codeid=? and situation=?");
    mysqli_stmt_bind_param($statement, "ii", $codeids,$sit);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id, $codeid, $userid,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $uids[$count]=$userid;
        $count++;
    }

}
function Take_usernames(){
    global $con,$uids,$unames;
    $count=0;
    foreach ($uids as $uid){
        $statement = mysqli_prepare($con, "select * from tblusers where id=?");
        mysqli_stmt_bind_param($statement, "i", $uid);
        mysqli_stmt_execute($statement);

        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $id, $fName, $lName, $email, $password, $isAdmin, $isGameCreator, $isActive, $registerDate);
        while (mysqli_stmt_fetch($statement)) {
            $unames[$count]=$fName;
            $count++;
        }
    }
}
function Create_Json(){
    global $uids,$unames,$userinfo;
    $size=count($uids);
    for ($i=0;$i<$size;$i++){
        $userinfo[$i]["userid"]=$uids[$i];
        $userinfo[$i]["username"]=$unames[$i];
    }
}
Take_codeids();
Take_userids();
Take_usernames();
Create_Json();
$response["userinfo"]=$userinfo;
echo json_encode($response);
?>