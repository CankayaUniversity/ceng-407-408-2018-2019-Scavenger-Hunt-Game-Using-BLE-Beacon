<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 15.04.2019
 * Time: 22:26
 */

require_once 'Database.php';
$response=array();

$id=$_POST["id"];
$name = $_POST["name"];
$lname = $_POST["surname"];
$pw = $_POST["pw"];
$email = $_POST["email"];
$date = $_POST["date"];
$isactive = $_POST["isActive"];
$isadmin = $_POST["isAdmin"];
$isgamecreator = $_POST["isGamecreator"];


function Updatebeacon()
{
    global $con,$response,$place,$uuid,$major,$minor,$beaconid,$gid;
    $statement = mysqli_query($con, "UPDATE beacons SET Gameid='".$gid."', Placename='".$place."', UUID='".$uuid."', Major='".$major."', Minor='".$minor."' WHERE Beaconid='".$beaconid."'");
    mysqli_stmt_execute($statement);
    $response["success"] = true;
}

function updateuser(){
    global $con,$id,$name,$lname,$pw,$email,$isadmin,$isgamecreator,$isactive,$date,$response;
    $statement = mysqli_query($con, "UPDATE tblusers SET fName='".$name."', lName='".$lname."', email='".$email."', pass='".$pw."', isAdmin=".$isadmin.", isGameCreator=".$isgamecreator.", isActive=".$isactive.", registerDate='".$date."' WHERE id='".$id."'");
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}
$response["success"]=false;
updateuser();

echo json_encode($response);

?>