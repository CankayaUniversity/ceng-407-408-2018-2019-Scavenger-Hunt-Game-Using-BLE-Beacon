<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 8.04.2019
 * Time: 14:10
 */
    require_once 'Database.php';
    $response=array();
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");

    $gid=$_POST["gameid"];
    $statement = mysqli_prepare($con, "select * from codes where gameid=?");
    mysqli_stmt_bind_param($statement, "i", $gid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $codeid, $gameid, $entrycode, $starttime, $Startdate, $endtime, $Enddate, $situation);

    $response["success"] = false;

    while (mysqli_stmt_fetch($statement)) {
        $response["success"] = true;
        $response["codeid"] = $codeid;
        $response["gameid"] = $gameid;
        $response["entrycode"] = $entrycode;
        $date_sdate=$Startdate;
        $date_stime=$starttime;
        $date_edate=$Enddate;
        $date_etime=$endtime;
        $response["starttime"] = $starttime;
        $response["startdate"] = $Startdate;
        $response["endtime"] = $endtime;
        $response["enddate"] = $Enddate;
        $response["situation"] = $situation;
    }

    $sdate=date_parse_from_format("j/n/Y",$date_sdate);
    $edate=date_parse_from_format("j/n/Y",$date_edate);
    $stime=date_parse_from_format("H:iP",$date_stime);
    $etime=date_parse_from_format("H:iP",$date_etime);
    $enddate=new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    $startdate=new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");
    $today=new DateTime("$year-$month-$day $hour:$minute");
    if ($today>$enddate){
        $status=0;
        $statements = mysqli_query($con, "UPDATE codes SET situation=".$status." WHERE codeid=".$codeid." ");
        mysqli_stmt_execute($statements);
        $response["situation"]=$status;
        $response["info"]="Your code is out of date, please update it.";
    }elseif ($today<$startdate){
        $response["info"]="Your code will start working later. it will work at $starttime $Startdate";
    }else{
        $response["info"]="Your code is up to date.";
    }

    echo json_encode($response);
?>