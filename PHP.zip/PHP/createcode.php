<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 26.03.2019
 * Time: 14:28
 */

require_once 'Database.php';
$response=array();
$gameid=$_POST["gameid"];
$code=$_POST["code"];
$starttime=$_POST["starttime"];
$startdate=$_POST["startdate"];
$endtime=$_POST["endtime"];
$enddate=$_POST["enddate"];
$situation=$_POST["situation"];

date_default_timezone_set('Etc/GMT-3');
$day=date("d");
$month=date("m");
$year=date("Y");
$hour=date("H");
$minute=date("i");
$today=new DateTime("$year-$month-$day $hour:$minute");
function checkcode(){
    global $con,$code;
    //$statement=mysqli_query($con,"select * from codes where entrycode=$code");
    $statement=mysqli_prepare($con,"select * from codes where entrycode=?");
    mysqli_stmt_bind_param($statement, "s", $code);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    $count=mysqli_stmt_num_rows($statement);
    mysqli_stmt_close($statement);
    if($count<1){
        return true;
    }else{
        return false;

    }
}
function updatecode(){
    global $con,$code,$gameid,$endtime,$enddate,$situation,$starttime,$startdate,$today;

    $sdate=date_parse_from_format("j/n/Y",$startdate);
    $edate=date_parse_from_format("j/n/Y",$enddate);
    $stime=date_parse_from_format("H:iP",$starttime);
    $etime=date_parse_from_format("H:iP",$endtime);
    $end=new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    $start=new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");
    if ($today>$end){
        $response["success"]=false;
        $response["error"]="Your end time can not be before the present time";
    }elseif ($today>$start){
        $response["success"]=false;
        $response["error"]="Your start time can not be before the present time";
    }elseif ($start>$end){
        $response["success"]=false;
        $response["error"]="your end date can not be before the start date";
    }else{
        $statement = mysqli_query($con, "UPDATE codes SET entrycode='".$code."',starttime='".$starttime."',Startdate='".$startdate."',endtime='".$endtime."',Enddate='".$enddate."',situation=".$situation." WHERE gameid=".$gameid." ");
        mysqli_stmt_execute($statement);
        $response["success"] = true;
    }

}




if(checkcode()){
    $response["success"]=true;
    updatecode();
}else{
    $response["success"]=false;
    $response["error"]="Code is already used in another game.";
}
echo json_encode($response);


?>