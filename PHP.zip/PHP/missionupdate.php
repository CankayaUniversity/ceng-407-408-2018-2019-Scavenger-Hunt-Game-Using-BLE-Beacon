<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 25.05.2019
 * Time: 17:37
 */
require_once 'Database.php';
$response=array();
$misid=$_POST["missionid"];
$misname=$_POST['missionname'];
$misdesc=$_POST['description'];
$misscore=$_POST['score'];
$bcn=$_POST['beacons'];
$enddate=$_POST['enddate'];
$endtime=$_POST['endtime'];
$startdate=$_POST['startdate'];
$starttime=$_POST['starttime'];
$beacons=json_decode($bcn,true);

function checktime(){
    global $response,$starttime,$startdate,$endtime,$enddate;
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");
    $today=new DateTime("$year-$month-$day $hour:$minute");

    $sdate=date_parse_from_format("j/n/Y",$startdate);
    $edate=date_parse_from_format("j/n/Y",$enddate);
    $stime=date_parse_from_format("H:iP",$starttime);
    $etime=date_parse_from_format("H:iP",$endtime);
    $end=new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    $start=new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");

    if ($today>$start){
        $response["success"]=false;
        $response["info"]="your starttime can not be before today";
        return false;
    }elseif($start>$end){
        $response["success"]=false;
        $response["info"]="your start time can not be later than your end time";
        return false;
    }elseif ($today>$end){
        $response["success"]=false;
        $response["info"]="your end time can not be before today";
        return false;
    }else{
        return true;
    }

}
function deletemissionbeacon(){
    global $con,$misid;
    $statement = mysqli_query($con, "DELETE FROM beaconmission WHERE mission_id= ".$misid." ");
    mysqli_stmt_execute($statement);
}
function addbeacons(){
    global $con,$beacons,$misid;
    foreach ($beacons as $id){
        $statement=mysqli_prepare($con,"insert into beaconmission(beacon_id,mission_id) values (?,?)");
        mysqli_stmt_bind_param($statement,"ii",$id,$misid);
        mysqli_stmt_execute($statement);
    }

}
function updatemission(){
    global $con,$misid,$misname,$misdesc,$misscore,$enddate,$endtime,$startdate,$starttime;
    $statement = mysqli_query($con, "UPDATE missions SET mission_name='".$misname."', mission_description='".$misdesc."',mission_starttime='".$starttime."',mission_startdate='".$startdate."',mission_endtime='".$endtime."', mission_enddate='".$enddate."', mission_score=".$misscore." WHERE mission_id=".$misid." ");
    mysqli_stmt_execute($statement);
}

if (checktime()){
    deletemissionbeacon();
    addbeacons();
    updatemission();
    $response["success"]=true;
}
echo json_encode($response);

?>