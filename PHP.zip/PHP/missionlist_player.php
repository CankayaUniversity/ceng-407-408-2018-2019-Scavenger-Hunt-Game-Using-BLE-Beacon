<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 28.04.2019
 * Time: 21:22
 */
require_once 'Database.php';
$response=array();
$missions=array();
$mis=array();
$userid=$_POST["userid"];
$gameid=$_POST["gameid"];

$beaconids=array();
$misids=array();



function takegame(){
    global $con,$gameid,$response,$misids;
    $sit=1;
    $count=0;
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");
    try {
        $today = new DateTime("$year-$month-$day $hour:$minute");
    } catch (Exception $e) {
    }
    $statement=mysqli_prepare($con,"select * from missions where game_id=? and situation=?");
    mysqli_stmt_bind_param($statement,"ii",$gameid,$sit);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $mission_id, $game_id, $mission_name,$mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$samplefoto,$minu,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $sdate=date_parse_from_format("j/n/Y",$mission_startdate);
        $edate=date_parse_from_format("j/n/Y",$mission_enddate);
        $stime=date_parse_from_format("H:iP",$mission_starttime);
        $etime=date_parse_from_format("H:iP",$mission_endtime);
        try {
            $enddate = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
        } catch (Exception $e) {
        }
        try {
            $startdate = new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");
        } catch (Exception $e) {
        }
        if ($today>$enddate){
            ;
        }elseif ($today<$startdate){
            ;
        }else{
            $response[$count][0]=1;
            $response[$count][1] = $mission_id;
            $misids[$count]=$mission_id;
            $response[$count][2] = $mission_name;
            $response[$count][3] = $mission_description;
            $response[$count][4] = $mission_type;
            $response[$count][5] = $mission_starttime;
            $response[$count][6] = $mission_startdate;
            $response[$count][7] = $mission_endtime;
            $response[$count][8] =$mission_enddate;
            $response[$count][9] =$mission_score;
            $response[$count][10] =$mission_done;
            $response[$count][11] =$isautocompare;
            $response[$count][12] =$samplefoto;
            $response[$count][13] =$minu;
            $response[$count][14] =$situation;
            $count++;
        }


    }
}
function checkaccomplish(){
    global $con,$userid,$response,$mis,$misids;
    $c=0;
    $x=0;
    foreach ($misids as $mid){
            $statement = mysqli_prepare($con, "select * from accomplishmission where userid=? and missionid=?");
            mysqli_stmt_bind_param($statement, "ii", $userid, $mid);
            mysqli_stmt_execute($statement);
            mysqli_stmt_store_result($statement);
            $count = mysqli_stmt_num_rows($statement);
            if ($count < 1) {
                $mis[$c]["mission_id"] = $response[$x][1];
                $mis[$c]["mission_name"] = $response[$x][2];
                $mis[$c]["mission_description"] = $response[$x][3];
                $mis[$c]["mission_type"] = $response[$x][4];
                $mis[$c]["mission_starttime"] = $response[$x][5];
                $mis[$c]["mission_startdate"] = $response[$x][6];
                $mis[$c]["mission_endtime"] = $response[$x][7];
                $mis[$c]["mission_enddate"] = $response[$x][8];
                $mis[$c]["mission_score"] = $response[$x][9];
                $mis[$c]["mission_done"] = $response[$x][10];
                $mis[$c]["isautocompare"] = $response[$x][11];
                $mis[$c]["samplefoto"] = $response[$x][12];
                $mis[$c]["minu"] = $response[$x][13];
                $mis[$c]["situation"] = $response[$x][14];
                $c++;
            }
            $x++;
    }

}

takegame();
checkaccomplish();
$missions["missions"]=$mis;
echo json_encode($missions);



?>