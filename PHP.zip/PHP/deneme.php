<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 6.03.2019
 * Time: 11:18
 */

require_once 'Database.php';
$userid=6;
$codesid=1;
function checkplayer(){
    global $con,$userid,$codesid;
    $statement=mysqli_prepare($con,"select * from joingame where codeid=? and userid=? ");
    mysqli_stmt_bind_param($statement,"ii",$codesid,$userid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    $count=mysqli_stmt_num_rows($statement);

    //echo "count=$count";
    if($count>0){
        return false;
    }else{
        return true;
    }
}

if (checkplayer()){
    echo "user yok ekleme yapılabilir";
}else{
    echo "user var";
}
//checkplayer();


?>