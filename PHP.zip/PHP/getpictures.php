<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 29.04.2019
 * Time: 21:40
 */
require_once 'Database.php';
$response=array();
$pictures=array();
$json=array();
$count=0;
$mid=$_POST["missionid"];
$sit=0;
$userids=array();

function getaccomplish(){
    global $con,$mid,$sit,$response,$userids;
    $count=0;
    $statement=mysqli_prepare($con,"select * from accomplishmission where missionid=? and situation=?");
    mysqli_stmt_bind_param($statement,"ii",$mid,$sit);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $acm_id,$gameid, $missionid, $userid,$score,$date,$time,$photo,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $response[$count]["missionid"]=$acm_id;
        $response[$count]["photo"]=$photo;
        $userids[$count]=$userid;
        $count++;
    }
}
function getusernames(){
    global $con,$userids,$response;
    $count=0;
    foreach ($userids as $id){
        $statement=mysqli_prepare($con,"select * from tblusers where id=?");
        mysqli_stmt_bind_param($statement,"i",$id);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $id, $fName, $lName, $email, $password, $isAdmin, $isGameCreator, $isActive, $registerDate);
        while (mysqli_stmt_fetch($statement)) {
            $response[$count]["username"]=$fName;
            $count++;
        }
    }

}
getaccomplish();
getusernames();

$pictures["pictures"]=$response;
echo json_encode($pictures);

?>