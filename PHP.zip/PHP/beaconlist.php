<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 31.03.2019
 * Time: 22:40
 */
require_once 'Database.php';
$response=array();
$beacon=array();
$count=0;
$gameid=$_POST["gameid"];
$statement=mysqli_prepare($con,"select * from beacons where gameid=?");
mysqli_stmt_bind_param($statement,"i",$gameid);
mysqli_stmt_execute($statement);
mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $Beaconid, $Gameid, $Placename,$UUID,$Major,$Minor);
while (mysqli_stmt_fetch($statement)) {
    $response[$count]["Beaconid"] = $Beaconid;
    $response[$count]["Placename"] = $Placename;
    $response[$count]["UUID"] = $UUID;
    $response[$count]["Major"] = $Major;
    $response[$count]["Minor"] = $Minor;
    $count++;
}
$beacon["Beacons"]=$response;
echo json_encode($beacon);
?>