<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 28.02.2019
 * Time: 22:48
 */

    require_once 'Database.php';
    $response=array();
    $e = $_POST["e-mail"];
    $pw = $_POST["pass"];
    $statement = mysqli_prepare($con, "select * from tblusers where email=? and pass=?");
    mysqli_stmt_bind_param($statement, "ss", $e, $pw);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id, $fName, $lName, $email, $password, $isAdmin, $isGameCreator, $isActive, $registerDate);

    $response["success"] = false;

    while (mysqli_stmt_fetch($statement)) {
        $response["success"] = true;
        $response["id"] = $id;
        $response["name"] = $fName;
        $response["surname"] = $lName;
        $response["password"] = $password;
        $response["email"] = $email;
        $response["isadmin"] = $isAdmin;
        $response["isgamecreator"] = $isGameCreator;
        $response["isactive"] = $isActive;
        $response["date"] = $registerDate;
    }

    echo json_encode($response);


?>