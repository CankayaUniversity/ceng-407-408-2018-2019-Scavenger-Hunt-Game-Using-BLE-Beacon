<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 25.05.2019
 * Time: 15:46
 */
require_once 'Database.php';
$misid=$_POST['missionid'];
$gid=$_POST['gameid'];
$allbeaconinfo=array();
$beaconsid=array();
$beaconmissioninfo=array();
$count=0;
$countmissionbeacon=0;
$response=array();

function getallbeacon(){
    global $con,$gid,$allbeaconinfo,$count;
    $statement=mysqli_prepare($con,"select Beaconid,Placename from beacons where Gameid=?");
    mysqli_stmt_bind_param($statement,"i",$gid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $Beaconid, $Placename);

    while (mysqli_stmt_fetch($statement)) {
        $allbeaconinfo[$count]["beaconid"]=$Beaconid;
        $allbeaconinfo[$count]["placename"]=$Placename;

        $count++;
    }
}
function getbeaconmissionsid(){
    global $con,$misid,$beaconsid;
    $statement=mysqli_prepare($con,"select beacon_id from beaconmission where mission_id=?");
    mysqli_stmt_bind_param($statement,"i",$misid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $beacon_id);
    $count=0;
    while (mysqli_stmt_fetch($statement)) {
        $beaconsid[$count]=$beacon_id;
        $count++;
    }
}
function getbeaconmissioninfo(){
    global $con,$beaconsid,$beaconmissioninfo,$countmissionbeacon;
    foreach ($beaconsid as $id){
        $statement=mysqli_prepare($con,"select Beaconid,Placename from beacons where Beaconid=?");
        mysqli_stmt_bind_param($statement,"i",$id);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $Beaconid, $Placename);
        while (mysqli_stmt_fetch($statement)) {
            $beaconmissioninfo[$countmissionbeacon]["beaconid"]=$Beaconid;
            $beaconmissioninfo[$countmissionbeacon]["placename"]=$Placename;

            $countmissionbeacon++;
        }
    }
}
function createjson(){
    global $beaconmissioninfo,$allbeaconinfo,$response;
    $response["allbeacons"]=$allbeaconinfo;
    $response["missionbeacons"]=$beaconmissioninfo;
}

getallbeacon();
getbeaconmissionsid();
getbeaconmissioninfo();
createjson();
echo json_encode($response);

?>