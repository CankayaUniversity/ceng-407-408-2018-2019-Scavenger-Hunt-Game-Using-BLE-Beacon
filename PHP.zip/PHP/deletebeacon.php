<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 31.03.2019
 * Time: 22:35
 */
require_once 'Database.php';

$beaconid=$_POST["beaconid"];
$response=array();
function Deletebeacon()
{
    global $con,$response,$beaconid;
    $statement = mysqli_query($con, "DELETE FROM beacons WHERE Beaconid=$beaconid");
    mysqli_stmt_execute($statement);
    $response["success"] = true;
}


$response["success"]=false;
Deletebeacon();
echo json_encode($response);
mysqli_close($con);
?>
?>