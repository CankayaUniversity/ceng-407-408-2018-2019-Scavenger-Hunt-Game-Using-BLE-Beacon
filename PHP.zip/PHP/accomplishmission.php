<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 29.04.2019
 * Time: 15:09
 */
require_once 'Database.php';
$response=array();
$uid=$_POST["userid"];
$gid=$_POST["gameid"];
$mid=$_POST["missionid"];
$picture=$_POST["photo"];
$enddate=null;
$endtime=null;
$type=null;
$compare=null;
$target_direction=null;
$mdone=null;
$mscore=null;
$accomplishid=null;
$sit=0;

$response["success"]=false;

date_default_timezone_set('Etc/GMT-3');
$day=date("d");
$month=date("m");
$year=date("Y");
$hour=date("H");
$minute=date("i");
$date=$day."/".$month."/".$year;
$time=$hour.":".$minute;
try {
    $today = new DateTime("$year-$month-$day $hour:$minute");
} catch (Exception $e) {
}
function getmission(){
    global $con,$mid,$endtime,$enddate,$type,$compare,$mdone,$mscore;
    $statement=mysqli_prepare($con,"select * from missions where mission_id=?");
    mysqli_stmt_bind_param($statement, "i", $mid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $mission_id,$game_id, $mission_name, $mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$samplephoto,$minu,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $endtime=$mission_endtime;
        $enddate=$mission_enddate;
        $type=$mission_type;
        $compare=$isautocompare;
        $mdone=$mission_done;
        $mscore=$mission_score;
    }
}
function savephoto(){
    global $response,$picture,$gid,$mid,$uid,$target_direction;
    $target_direction="huntgame/photos";
    if (!file_exists($target_direction)){
        mkdir($target_direction, 0777, true);
    }
    $target_direction=$target_direction."/".$gid."_".$mid."_".$uid.".jpg";
    if (file_put_contents($target_direction,base64_decode($picture))){
        $resim=$target_direction;
        list($mevcutgenislik,$mevcutyukseklik)=getimagesize($resim);
        $genislik=259;
        $yukseklik=194;
        $hedef=imagecreatetruecolor($genislik,$yukseklik);
        $kaynak=imagecreatefromjpeg($resim);
        imagecopyresampled($hedef,$kaynak,0,0,0,0,$genislik,$yukseklik,$mevcutgenislik,$mevcutyukseklik);
        $yeniisim=$uid."_".$gid."_".$mid."_edited";
        $yenidirection="huntgame/photos/{$yeniisim}.jpg";
        imagejpeg($hedef,$yenidirection,20);
        imagedestroy($hedef);
        unlink($resim);
        $target_direction=$yenidirection;
        $response["success"]=true;
    }else{
        $response["success"]=false;
        $response["error"]="picture upload failed";
    }

}
function checktime(){
    global $enddate,$endtime,$today,$response;
    $edate=date_parse_from_format("j/n/Y",$enddate);
    $etime=date_parse_from_format("H:iP",$endtime);
    try {
        $enddate = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    } catch (Exception $e) {
    }
    if($today>$enddate){
        $response["success"]=false;
        $response["error"]="Mission is already end";
        return false;
    }else{
        $response["success"]=true;
        return true;
    }
}
function accomplish()
{
    global $con, $uid, $gid, $mid, $target_direction, $date, $time, $response,$sit;
    $score=0;
    $statement = mysqli_prepare($con, "insert into accomplishmission(gameid,missionid,userid,score,findate,fintime,photo,situation) values(?,?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($statement, "iiiisssi", $gid, $mid, $uid, $score, $date, $time, $target_direction,$sit);
    mysqli_stmt_execute($statement);
    $response["success"]=true;

}
function getaccomplishid(){
    global $con,$gid,$mid,$uid,$accomplishid;
    $statement=mysqli_prepare($con,"select * from accomplishmission where missionid=? and gameid=? and userid=?");
    mysqli_stmt_bind_param($statement, "iii", $mid,$gid,$uid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $acm_id,$gameid, $missionid, $userid,$score,$findate,$fintime,$photo,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $accomplishid=$acm_id;
    }

}
function setscore(){
    global $con, $mdone, $mscore, $type, $compare,$accomplishid,$target_direction,$sit;
    $score=null;
    if ($type == 3 && $compare == 0) {
        $sit=0;
        $score=0;
    }elseif ($type == 3 && $compare == 1){
        $sit=1;
        $sampletarget=getsamplespath();
        $sim=findSimilarityBetweenImages($target_direction,$sampletarget);
        if ($sim<25){
            if ($mdone < 3) {
                $score = $mscore / ($mdone + 1);
            } else {
                $score = $mscore / 3;
            }
        }else{
            $score=0;
        }

    }else {
        $sit=1;
        if ($mdone < 3) {
            $score = $mscore / ($mdone + 1);
        } else {
            $score = $mscore / 3;
        }
    }
    $statement = mysqli_query($con, "UPDATE accomplishmission SET score= ".$score.",situation=".$sit." WHERE acm_id=".$accomplishid." ");
    mysqli_stmt_execute($statement);

}
function getsamplespath(){
    global $con,$mid;

    $statement=mysqli_prepare($con,"select * from missions where mission_id=?");
    mysqli_stmt_bind_param($statement,"i",$mid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $mission_id,$game_id, $mission_name, $mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$samplephoto,$minu);
    while (mysqli_stmt_fetch($statement)) {
        $samplelocation=$samplephoto;
    }
    return $samplelocation;
}

function findSimilarityBetweenImages($a, $b){
    $url="http://95.183.182.85:81/huntgame/";
    $a=$url.$a;
    $b=$url.$b;

    $i1 = @imagecreatefromstring(file_get_contents($a));
    $i2 = @imagecreatefromstring(file_get_contents($b));

    $sx1 = imagesx($i1);
    $sy1 = imagesy($i1);

    $different_pixels = 0;

    for ($x = 0; $x < $sx1; $x++) {
        for ($y = 0; $y < $sy1; $y++) {

            $rgb1 = imagecolorat($i1, $x, $y);
            $pix1 = imagecolorsforindex($i1, $rgb1);

            $rgb2 = imagecolorat($i2, $x, $y);
            $pix2 = imagecolorsforindex($i2, $rgb2);

            if ($pix1 !== $pix2) {
                $different_pixels++;

            }

        }
    }


    if (!$different_pixels) {
        return 0;
    } else {
        $total = $sx1 * $sy1;
        return number_format(100 * $different_pixels / $total, 2);
    }
}

function updatemissiondone(){
    global $con,$mid,$response,$mdone;
    $misdone=$mdone+1;
    $statement = mysqli_query($con, "UPDATE missions SET mission_done='".$misdone."' WHERE mission_id='".$mid."' ");
    mysqli_stmt_execute($statement);
    $response["success"]=true;

}
function checkmissionaccomplish(){
	global $con,$uid,$mid,$gid,$response;
	$statement = mysqli_prepare($con, "Select * from accomplishmission where gameid=? and missionid=? and userid=?");
    	mysqli_stmt_bind_param($statement, "iii", $gid, $mid, $uid);
    	mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        $count = mysqli_stmt_num_rows($statement);
        if($count>0){
            $response["success"]=false;
            $response["error"]="You alredy did this game";
            return false;
        }else{
            $response["success"]=true;
            return true;
        }
}




if(checkmissionaccomplish()){
getmission();
if (checktime()){
    if($type==3){
        savephoto();
    }else{
        $target_direction="-1";
    }
    accomplish();
    getaccomplishid();
    setscore();
    updatemissiondone();
}
}
echo json_encode($response);

?>