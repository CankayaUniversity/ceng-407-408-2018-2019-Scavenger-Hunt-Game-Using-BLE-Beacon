<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 22.04.2019
 * Time: 12:18
 */
require_once 'Database.php';

$response=array();
$gameid=$_POST["gameid"];
$mission_name=$_POST["missionname"];
$mission_description=$_POST["missiondescription"];
$mission_score=$_POST["missionscore"];
$beaconid=$_POST["beaconid"];
$isautocompare=$_POST["compare"];
$min=$_POST["missionminute"];
$samplephoto=$_POST["imagedata"];
$mission_startdate=$_POST["startdate"];
$mission_starttime=$_POST["starttime"];
$mission_enddate=$_POST["enddate"];
$mission_endtime=$_POST["endtime"];
$mission_type=$_POST["misiontype"];
$mission_done=0;
$bids=json_decode($beaconid,true);
$chechupload=true;
$situation=1;
$target_direction=-"1";
if (strcmp($samplephoto,"-1")!=0) {
    $target_direction = "huntgame/samples";
    if (!file_exists($target_direction)){
        mkdir($target_direction,0777,true);
    }
    $target_direction = $target_direction ."/". rand() . "_". time() . ".jpg";
    if (file_put_contents($target_direction, base64_decode($samplephoto))) {
        $resim=$target_direction;
        list($mevcutgenislik,$mevcutyukseklik)=getimagesize($resim);
        $genislik=259;
        $yukseklik=194;
        $hedef=imagecreatetruecolor($genislik,$yukseklik);
        $kaynak=imagecreatefromjpeg($resim);
        imagecopyresampled($hedef,$kaynak,0,0,0,0,$genislik,$yukseklik,$mevcutgenislik,$mevcutyukseklik);
        $yeniisim=$gameid."_".$mission_name."_".$mission_description;
        $yenidirection="huntgame/samples/{$yeniisim}.jpg";
        imagejpeg($hedef,$yenidirection,20);
        imagedestroy($hedef);
        unlink($resim);
        $target_direction=$yenidirection;
        $response["success"] = true;
    } else {
        $chechupload=false;
        $response["success"] = false;
        $response["info"] = "upload photo is not successful";
    }
}

function checkmission(){
    global $con,$response,$gameid,$mission_name,$mission_description;
    $statement=mysqli_prepare($con,"select * from missions where gameid=? and mission_name=? and mission_description=?");
    mysqli_stmt_bind_param($statement, "iss", $gameid,$mission_name,$mission_description);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    $count=mysqli_stmt_num_rows($statement);
    if ($count<1){
        $response["info"]="you already have this mission";
        return true;
    }else{
        return false;
    }
}
function checktime(){
    global $response,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate;
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");
    try {
        $today = new DateTime("$year-$month-$day $hour:$minute");
    } catch (Exception $e) {
    }

    $sdate=date_parse_from_format("j/n/Y",$mission_startdate);
    $edate=date_parse_from_format("j/n/Y",$mission_enddate);
    $stime=date_parse_from_format("H:iP",$mission_starttime);
    $etime=date_parse_from_format("H:iP",$mission_endtime);
    try {
        $end = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    } catch (Exception $e) {
    }
    try {
        $start = new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");
    } catch (Exception $e) {
    }

    if ($today>$start){
        $response["success"]=false;
        $response["info"]="The start time must be later than the current time.";
        return false;
    }elseif($start>$end){
        $response["success"]=false;
        $response["info"]="your start time can not be later than your end time";
        return false;
    }elseif ($today>$end){
        $response["success"]=false;
        $response["info"]="your end time can not be before today";
        return false;
    }else{
        return true;
    }

}
function createmission(){
    global $con,$response,$gameid,$mission_name,$mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$target_direction,$min,$situation;
    $statement=mysqli_prepare($con,"insert into missions(game_id,mission_name,mission_description,mission_type,mission_starttime,mission_startdate,mission_endtime,mission_enddate,mission_score,mission_done,isautocompare,samplefoto,minu,situation) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
    mysqli_stmt_bind_param($statement,"ississssiiisii",$gameid,$mission_name,$mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$target_direction,$min,$situation);
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}

function checkmissionid(){
    global $con,$gameid,$mission_name,$mission_description,$missionid;
    $statement=mysqli_prepare($con,"select mission_id from missions where game_id=? and mission_name=? and mission_description=?");
    mysqli_stmt_bind_param($statement,"iss",$gameid,$mission_name,$mission_description);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $mission_id);
    while (mysqli_stmt_fetch($statement)) {
        $missionid=$mission_id;
    }
    addbeacons($missionid);
}

function addbeacons($missionid){
    global $con,$bids;
    foreach ($bids as $id){
        $statement=mysqli_prepare($con,"insert into beaconmission(beacon_id,mission_id) values (?,?)");
        mysqli_stmt_bind_param($statement,"ii",$id,$missionid);
        mysqli_stmt_execute($statement);
    }

}
if ($chechupload==true) {
    if (checktime()) {
        if (checkmission()) {
            createmission();
            checkmissionid();
        }
    }
}

echo json_encode($response);

?>