<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 15.04.2019
 * Time: 20:17
 */

require_once 'Database.php';
$response=array();
$codeid=$_POST["codeid"];
$situation=$_POST["situation"];
function updatecode(){
    global $con,$codeid,$situation;
    $statement = mysqli_query($con, "UPDATE codes SET situation='".$situation."' WHERE codeid='".$codeid."'");
    mysqli_stmt_execute($statement);
}
updatecode();
$response["success"]=true;

echo json_encode($response);
?>