<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 31.03.2019
 * Time: 22:40
 */
require_once 'Database.php';
/*$response=array();
$beacon=array();
$count=0;
$gameid=1;
$statement=mysqli_prepare($con,"select * from beacons where gameid=?");
mysqli_stmt_bind_param($statement,"i",$gameid);
mysqli_stmt_execute($statement);
mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $Beaconid, $Gameid, $Placename,$UUID,$Major,$Minor);
while (mysqli_stmt_fetch($statement)) {
    $response[$count]["Beaconid"] = $Beaconid;
    $response[$count]["Placename"] = $Placename;
    $response[$count]["UUID"] = $UUID;
    $response[$count]["Major"] = $Major;
    $response[$count]["Minor"] = $Minor;
    $count++;
}
$beacon["Beacons"]=$response;
echo json_encode($beacon);*/
$description="new";
$id=5;
$gid=null;
$codesid=null;
$code="123456";
$response=array();
function checkcode(){
    global $con,$code,$codesid,$response,$gid;
    $statement=mysqli_prepare($con,"select codeid,gameid,endtime,Enddate from codes where entrycode=?");
    mysqli_stmt_bind_param($statement, "s", $code);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    $count=mysqli_stmt_num_rows($statement);
    mysqli_stmt_bind_result($statement, $codeid,$gameid,$endtime,$Enddate);
    while (mysqli_stmt_fetch($statement)) {
        $codesid=$codeid;
        $gid=$gameid;
        $ldate=$Enddate;
        $ltime=$endtime;
    }
    mysqli_stmt_close($statement);
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");
    $today=new DateTime("$year-$month-$day $hour:$minute:00");

    $edate=date_parse_from_format("j/n/Y",$ldate);
    $etime=date_parse_from_format("H:iP",$ltime);
    $enddate = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]:00");

    if($count>0){

        if($today<$enddate){
            $response["success"]=true;
            return true;
        }else{
            $response["success"]=false;
            $response["error"]="Code is out of date";
            return false;

        }


    }else{
        $response["success"]=false;
        $response["error"]="Code is invalid";

        return false;
    }
}
if (checkcode()){
    echo json_encode($response);
}else{
    echo json_encode($response);
}



?>