<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 29.04.2019
 * Time: 22:42
 */
require_once 'Database.php';
$response=array();
$mid=$_POST["accomplishid"];
$confirm=$_POST["confirm"];
$score=0;
$sit=1;
$mdone=null;
$misid=null;
$newscore=null;

function denied(){
    global $con,$score,$sit,$mid,$response;
    $statement = mysqli_query($con, "UPDATE accomplishmission SET score=".$score.",situation=".$sit." WHERE acm_id=".$mid." ");
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}

function getaccomplishmission(){
    global $con,$mid,$misid;
    $statement=mysqli_prepare($con,"select * from accomplishmission where acm_id=?");
    mysqli_stmt_bind_param($statement, "i", $mid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $acm_id,$gameid, $missionid, $userid,$score,$date,$time,$photo,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $misid=$missionid;
    }
}
function getmission(){
    global $con,$misid,$mdone,$score;
    $statement=mysqli_prepare($con,"select * from missions where mission_id=?");
    mysqli_stmt_bind_param($statement, "i", $misid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $mission_id,$game_id, $mission_name, $mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$beacon_startid,$beacon_endid,$isautocompare,$samplephoto,$minu);
    while (mysqli_stmt_fetch($statement)) {
        $mdone=$mission_done;
        $score=$mission_score;
    }
}
function calculatescore(){
    global $mdone,$score,$newscore;
    if ($mdone<3){
        $newscore=$score/($mdone+1);
    }else{
        $newscore=$score/3;
    }
}
function updatemissiondone(){
    global $con,$misid,$response,$mdone;
    $misdone=$mdone+1;
    $statement = mysqli_query($con, "UPDATE missions SET mission_done=".$misdone." WHERE mission_id=".$misid." ");
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}
function confirm(){
    global $con,$newscore,$sit,$mid,$response;
    $statement = mysqli_query($con, "UPDATE accomplishmission SET score=".$newscore.",situation=".$sit." WHERE acm_id=".$mid." ");
    mysqli_stmt_execute($statement);
    $response["success"]=true;
}
if ($confirm==1){
    getaccomplishmission();
    getmission();
    calculatescore();
    updatemissiondone();
    confirm();
}else{
    denied();
}
echo json_encode($response);

?>