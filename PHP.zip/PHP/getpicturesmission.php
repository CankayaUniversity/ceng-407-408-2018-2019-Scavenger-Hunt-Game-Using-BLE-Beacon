<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 29.04.2019
 * Time: 21:14
 */
require_once 'Database.php';
$response=array();
$missions=array();
$json=array();
$count=0;
$gid=$_POST["gameid"];
$type=3;
$count=0;
$statement=mysqli_prepare($con,"select * from missions where game_id=? and mission_type=?");
mysqli_stmt_bind_param($statement,"ii",$gid,$type);
mysqli_stmt_execute($statement);
mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $mission_id,$game_id, $mission_name, $mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$samplephoto,$minu,$situation);
while (mysqli_stmt_fetch($statement)) {
    $response[$count]["missionid"]=$mission_id;
    $response[$count]["missionname"]=$mission_name;
    $count++;
}

$missions["missions"]=$response;
echo json_encode($missions);
?>