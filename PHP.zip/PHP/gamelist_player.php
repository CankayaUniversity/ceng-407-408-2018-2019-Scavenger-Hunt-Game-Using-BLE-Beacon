<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 28.04.2019
 * Time: 20:43
 */
require_once 'Database.php';
$codeids=array();
$gameids=array();
$games=array();
$gamedefs=array();
$count=0;
$id=$_POST["id"];
$sit=1;
function takecodeid()
{
    global $con,$id,$sit,$codeids,$count;
    $statement = mysqli_prepare($con, "select * from joingame where userid=? and situation=?");
    mysqli_stmt_bind_param($statement, "ii", $id, $sit);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id, $codeid, $userid, $situation);
    while (mysqli_stmt_fetch($statement)) {
        $codeids[$count] = $codeid;
        $count++;
    }
}
function takegameids(){
    global $con,$codeids,$count,$gameids;
    $count=0;
    foreach ($codeids as $cid){
        $statement = mysqli_prepare($con, "select * from codes where codeid=?");
        mysqli_stmt_bind_param($statement, "i", $cid);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $codeid, $gameid, $entrycode, $starttime,$Startdate,$endtime,$Enddate,$situation);
        while (mysqli_stmt_fetch($statement)) {
            $gameids[$count] = $gameid;
            $count++;
        }

    }
}

function takegames(){
    global $con,$count,$gameids,$gamedefs;
    $count=0;
    foreach ($gameids as $gid){
        $statement = mysqli_prepare($con, "select * from game where gameid=?");
        mysqli_stmt_bind_param($statement, "i", $gid);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $gameid, $def, $userid);
        while (mysqli_stmt_fetch($statement)) {
            $gamedefs[$count]["id"] = $gameid;
            $gamedefs[$count]["description"]=$def;
            $gamedefs[$count]["userid"]=$userid;
            $count++;
        }
    }

}
takecodeid();
takegameids();
takegames();

$games["games"]=$gamedefs;
echo json_encode($games);
?>