<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 31.03.2019
 * Time: 22:26
 */
require_once 'Database.php';

$place=$_POST["place"];
$uuid=$_POST["uuid"];
$major=$_POST["major"];
$minor=$_POST["minor"];
$beaconid=$_POST["beaconid"];
$gid=$_POST["gameid"];
$response=array();
function Updatebeacon()
{
    global $con,$response,$place,$uuid,$major,$minor,$beaconid,$gid;
    $statement = mysqli_query($con, "UPDATE beacons SET Gameid='".$gid."', Placename='".$place."', UUID='".$uuid."', Major='".$major."', Minor='".$minor."' WHERE Beaconid='".$beaconid."'");
    mysqli_stmt_execute($statement);
    $response["success"] = true;
}

$response["success"]=false;
Updatebeacon();

echo json_encode($response);
mysqli_close($con);
?>