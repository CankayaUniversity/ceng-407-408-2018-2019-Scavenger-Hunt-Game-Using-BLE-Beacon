<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 7.05.2019
 * Time: 13:03
 */
require_once 'Database.php';
$response=array();
$misid=$_POST["missionid"];

function deletemission(){
    global $con,$misid;
    $statement = mysqli_query($con, "DELETE FROM missions WHERE mission_id= ".$misid." ");
    mysqli_stmt_execute($statement);
}
function deletemissionbeacon(){
    global $con,$misid;
    $statement = mysqli_query($con, "DELETE FROM beaconmission WHERE mission_id= ".$misid." ");
    mysqli_stmt_execute($statement);
}
if ($misid==null){
    $response["success"]=false;
}else{
    deletemission();
    deletemissionbeacon();
    $response["success"]=true;
}
echo json_encode($response);

?>