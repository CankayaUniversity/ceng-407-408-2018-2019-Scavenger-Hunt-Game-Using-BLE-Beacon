<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 13.05.2019
 * Time: 21:31
 */
require_once 'Database.php';
$uid=$_POST["userid"];
$gid=$_POST["gameid"];
$cid=null;
$response=array();
function Take_codeid(){
    global $con,$gid,$cid;
    $statement = mysqli_prepare($con, "select * from codes where gameid=?");
    mysqli_stmt_bind_param($statement, "i", $gid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $codeid, $gameid, $entrycode, $starttime, $Startdate, $endtime, $Enddate,$situation);
    while (mysqli_stmt_fetch($statement)) {
        $cid=$codeid;
    }
}
function Deban_player(){
    global $con,$uid,$cid;
    $sit=1;
    $statement = mysqli_query($con, "UPDATE joingame SET situation=".$sit." WHERE codeid=".$cid." and userid=".$uid." ");
    mysqli_stmt_execute($statement);

}
if ($uid==null || $gid==null){
    $response["success"]=false;
}else{
    Take_codeid();
    Deban_player();
    $response["success"]=true;
}
echo json_encode($response);
?>