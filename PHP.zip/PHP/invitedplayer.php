<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 8.04.2019
 * Time: 22:38
 */

require_once 'Database.php';
$response=array();
$usid=$_POST["userid"];
$gid=$_POST["gameid"];
$active=$_POST["isactive"];
$uid=json_decode($usid,true);

function createinviteplayer(){
    global $con,$response,$uid,$gid,$active;
    foreach ($uid as $row){
        $statement = mysqli_prepare($con, "insert into invitedplayer(gameid,userid,isactive) values(?,?,?)");
        mysqli_stmt_bind_param($statement, "iii", $gid, $row,$active);
        mysqli_stmt_execute($statement);
    }
    $response["success"]=true;
    mysqli_close($con);
}
if ($gid==null || $active==null){
    $response["success"]=false;
}else {
    createinviteplayer();
}
echo json_encode($response);


?>