<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 26.05.2019
 * Time: 10:43
 */
require_once 'Database.php';
$gid=$_POST["gameid"];
$usersid=$_POST["id"];
$personalscore=null;
$response=array();
$uid=array();
$scr=array();
$unames=array();
$scoreboard=array();
function getaccomplish(){
    global $con,$gid,$uid,$scr;
    $statement = mysqli_prepare($con, "select * from accomplishmission where gameid=?");
    mysqli_stmt_bind_param($statement, "i", $gid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $acm_id, $gameid, $missionid, $userid, $score, $date, $time, $photo,$situation);

    $count=0;
    while (mysqli_stmt_fetch($statement)) {
        if ($count==0){
            $uid[$count]=$userid;
            $scr[$count]=$score;
        }else{
            $i=0;
            $sit=0;
            while($i<$count){
                if ($uid[$i]==$userid){
                    $scr[$i]=$scr[$i]+$score;
                    $sit=1;
                    break;
                }
                $i++;
            }
            if ($sit==0){
                $uid[$count]=$userid;
                $scr[$count]=$score;
            }
        }
        $count++;
    }
}
function getnames(){
    global $con,$uid,$unames;
    $count=0;
    foreach ($uid as $id){
        $statement = mysqli_prepare($con, "select * from tblusers where id=?");
        mysqli_stmt_bind_param($statement, "i", $id);
        mysqli_stmt_execute($statement);

        mysqli_stmt_store_result($statement);
        mysqli_stmt_bind_result($statement, $id, $fName, $lName, $email, $password, $isAdmin, $isGameCreator, $isActive, $registerDate);
        while (mysqli_stmt_fetch($statement)){
            $unames[$count]=$fName;
            $count++;
        }
    }
}
function bubble_sort() {
    global $unames,$scr;
    $size = count($scr)-1;
    for ($i=0; $i<$size; $i++) {
        for ($j = 0; $j < $size - $i; $j++) {
            $k = $j + 1;
            if ($scr[$k] > $scr[$j]) {
                $tempscr=$scr[$k];
                $tempname=$unames[$k];
                $scr[$k]=$scr[$j];
                $unames[$k]=$unames[$j];
                $scr[$j]=$tempscr;
                $unames[$j]=$tempname;
            }
        }
    }
}
function getpersonalscore(){
    global $usersid,$personalscore,$uid,$scr;
    $count=0;
    $check=0;
    foreach ($uid as $id){
        if ($usersid==$id){
            $personalscore=$scr[$count];
            $check=1;
        }
        $count++;
    }
    if ($check==0){
        $personalscore=0;
    }

}
function Create_Json(){
    global $scr,$unames,$response;
    $size=count($scr);
    if ($size<10){
        for ($i=0;$i<$size;$i++){
            $response[$i]["username"]=$unames[$i];
            $response[$i]["score"]=$scr[$i];
        }
    }else{
        for ($i=0;$i<10;$i++){
            $response[$i]["username"]=$unames[$i];
            $response[$i]["score"]=$scr[$i];
        }
    }
}

getaccomplish();
getnames();
getpersonalscore();
if ($scr!=null && $unames!=null){
    bubble_sort();
}
Create_Json();



$scoreboard["scoreboard"]=$response;
$scoreboard["personalscore"]=$personalscore;
echo json_encode($scoreboard);


?>