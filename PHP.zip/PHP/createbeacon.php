<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 31.03.2019
 * Time: 22:12
 */
require_once 'Database.php';
$gameid=$_POST["gameid"];
$place=$_POST["placename"];
$uuid=$_POST["UUID"];
$major=$_POST["major"];
$minor=$_POST["minor"];
$response=array();
function Createbeacon()
{
    global $con,$response,$gameid,$place,$uuid,$major,$minor;
    $statement = mysqli_prepare($con, "insert into beacons(Gameid,Placename,UUID,Major,Minor) values(?,?,?,?,?)");
    mysqli_stmt_bind_param($statement, "issii", $gameid, $place, $uuid, $major, $minor);
    mysqli_stmt_execute($statement);
    $response["success"] = true;
}
function checkavailable(){
    global $con,$response,$gameid,$uuid;
    $statement = mysqli_prepare($con, "SELECT * FROM beacons WHERE Gameid =? and UUID=?");
    mysqli_stmt_bind_param($statement, "is", $gameid, $uuid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    $count = mysqli_stmt_num_rows($statement);
    if ($count < 1){
        return true;
    }else {
        $response["error"]="Beacon is already exist";
        return false;
    }
}
$response["success"]=false;
if (checkavailable()){
    Createbeacon();
}
echo json_encode($response);

?>