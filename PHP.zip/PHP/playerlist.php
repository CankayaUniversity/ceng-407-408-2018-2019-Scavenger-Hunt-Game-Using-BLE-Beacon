<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 8.04.2019
 * Time: 22:50
 */
    require_once 'Database.php';
    $response=array();
    $player=array();
    $json=array();
    $count=0;
    $active=$_POST["isactive"];
    $gc=$_POST["gc"];
    $admin=$_POST["admin"];
    $statement=mysqli_prepare($con,"select * from tblusers where isGameCreator=? and isAdmin=? and isActive=?");
    mysqli_stmt_bind_param($statement,"iii",$gc,$admin,$active);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id, $fName,$lName, $email,$pass,$isAdmin,$isGameCreator,$isActive,$registerDate);
    while (mysqli_stmt_fetch($statement)) {
        $response[$count]["playerid"] = $id;
        $response[$count]["playername"] = $fName;
        $response[$count]["playeremail"] = $email;
        $count++;
    }
    $player["players"]=$response;
    echo json_encode($player);
?>