<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 18.03.2019
 * Time: 19:08
 */

require_once 'Database.php';
$response=array();
$games=array();
$json=array();
$count=0;
$id=$_POST["id"];
$statement=mysqli_prepare($con,"select * from game where userid=?");
mysqli_stmt_bind_param($statement,"i",$id);
mysqli_stmt_execute($statement);
mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $id, $def, $userid);
while (mysqli_stmt_fetch($statement)) {
    $response[$count]["id"] = $id;
    $response[$count]["description"] = $def;
    $response[$count]["userid"] = $userid;
    $count++;
}
$games["games"]=$response;
echo json_encode($games);

?>