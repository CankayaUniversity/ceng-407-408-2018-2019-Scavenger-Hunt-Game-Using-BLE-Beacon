<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 30.05.2019
 * Time: 21:03
 */
require_once 'Database.php';
$gid=$_POST["gameid"];
$uid=$_POST["id"];
$response=array();
$code=null;


function findcodeid(){
    global $con,$gid,$code;
    $statement = mysqli_prepare($con, "select codeid from codes where gameid=?");
    mysqli_stmt_bind_param($statement, "i", $gid);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $codeid);
    while (mysqli_stmt_fetch($statement)) {
        $code=$codeid;
    }
}
function deletejoingame(){
    global $con,$uid,$code;
    $statement = mysqli_query($con, "DELETE FROM joingame WHERE codeid= ".$code." and userid=".$uid." ");
    mysqli_stmt_execute($statement);
}
function deleteaccomplish(){
    global $con,$gid,$uid;
    $statement = mysqli_query($con, "DELETE FROM joingame WHERE gameid= ".$gid." and userid=".$uid." ");
    mysqli_stmt_execute($statement);

}
if ($gid==null || $uid==null){
    $response["success"]=false;
}else {
    findcodeid();
    deletejoingame();
    deleteaccomplish();
    $response["success"]=true;
}
echo json_encode($response);
