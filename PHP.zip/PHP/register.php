﻿<?php

    require_once 'Database.php';
    $response=array();
    $name=$_POST["name"];
    $lastname=$_POST["lastname"];
    $email=$_POST["email"];
    $pw=$_POST["password"];
    $isadmin=$_POST["isAdmin"];
    $isgamecreator=$_POST["isGameCreator"];
    $isactive=$_POST["isActive"];
    $date=$_POST["registerDate"];
    function Registeruser()
    {
        global $con,$response,$date,$email,$isactive,$isgamecreator,$isadmin,$name,$lastname,$pw;
        $statement = mysqli_prepare($con, "insert into tblusers(fName,lName,email,pass,isAdmin,isGameCreator,isActive,registerDate) values(?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($statement, "ssssiiis", $name, $lastname, $email, $pw, $isadmin, $isgamecreator, $isactive, $date);
        mysqli_stmt_execute($statement);
        $response["success"] = true;
    }
    function emailAvailable() {
        global $con, $email,$response;
        $statement = mysqli_prepare($con, "SELECT * FROM TblUsers WHERE email = ?");
        mysqli_stmt_bind_param($statement, "s", $email);
        mysqli_stmt_execute($statement);
        mysqli_stmt_store_result($statement);
        $count = mysqli_stmt_num_rows($statement);
        mysqli_stmt_close($statement);
        if ($count < 1){
            return true;
        }else {
            $response["error"]="Email is already exist";
            return false;
        }
    }
    $response["success"]=false;
    if (emailAvailable()){
        $response["success"]=true;
        Registeruser();
    }
    echo json_encode($response);
    mysqli_close($con);
?>
