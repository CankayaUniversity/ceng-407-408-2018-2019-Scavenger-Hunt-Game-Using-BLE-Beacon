<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 15.05.2019
 * Time: 19:29
 */

$a="http://95.183.182.85:81/huntgame/photos/1.jpg";
$b="http://95.183.182.85:81/huntgame/photos/2.jpg";
$c="http://95.183.182.85:81/huntgame/photos/3.jpg";
/*function findSimilarityBetweenImages($imagePathA, $imagePathB, $accuracy){


    //if images are jpeg
    $imageA = imagecreatefromjpeg($imagePathA);
    $imageB = imagecreatefromjpeg($imagePathB);

    //get image resolution
    $imageWidth = imagesx($imageA);
    $imageHeight = imagesy($imageA);

    $density = $accuracy * 5;
    $xIncrement = round($imageWidth/$density);
    $yIncrement = round($imageHeight/$density);

    //Compare the color of each point while looping through.
    $matchingPoints = 0;

    for ($y=0; $y < $density; $y++) {
        for ($x=0; $x < $density; $x++){

            $colorsa = colorData($imageA, $x*$xIncrement, $y*$yIncrement);
            $colorsb = colorData($imageB, $x*$xIncrement, $y*$yIncrement);

            if(colorsMatch($colorsa, $colorsb)){
                $matchingPoints++; //Match between points.
            }
        }
    }

    $totalPoints = $imageWidth * $imageHeight;

    //A similarity or percentage of match between the two images.
    $similarity = $matchingPoints*(100/$totalPoints);
    return $similarity;
}
function colorData($imageA, $x, $y){
    $rgb = imagecolorat($imageA, $x, $y);
    return imagecolorsforindex($imageA, $rgb);
}
function colorsMatch($colorsa, $colorsb){
    //Compare the R, G, and B values
    return colorComp($colorsa['red'], $colorsb['red']) && colorComp($colorsa['green'], $colorsb['green']) && colorComp($colorsa['blue'], $colorsb['blue']);
}
function colorComp($color, $c){
    //To see if the points match
    return ($color >= $c-2 && $color <= $c+2);
}*/

//$result=findSimilarityBetweenImages($a,$b,1);
$i1 = @imagecreatefromstring(file_get_contents($a));
$i2 = @imagecreatefromstring(file_get_contents($c));

// check if we were given garbage
if (!$i1) {
    echo  ' a is not a valid image';
    exit(1);
}
if (!$i2) {
    echo ' b is not a valid image';
    exit(1);
}

// dimensions of the first image
$sx1 = imagesx($i1);
$sy1 = imagesy($i1);

// compare dimensions
if ($sx1 !== imagesx($i2) || $sy1 !== imagesy($i2)) {
    echo "The images are not even the same size";
    exit(1);
}

// create a diff image
$diffi = imagecreatetruecolor($sx1, $sy1);
$green = imagecolorallocate($diffi, 0, 255, 0);
imagefill($diffi, 0, 0, imagecolorallocate($diffi, 0, 0, 0));

// increment this counter when encountering a pixel diff
$different_pixels = 0;

// loop x and y
for ($x = 0; $x < $sx1; $x++) {
    for ($y = 0; $y < $sy1; $y++) {

        $rgb1 = imagecolorat($i1, $x, $y);
        $pix1 = imagecolorsforindex($i1, $rgb1);

        $rgb2 = imagecolorat($i2, $x, $y);
        $pix2 = imagecolorsforindex($i2, $rgb2);

        if ($pix1 !== $pix2) { // different pixel
            // increment and paint in the diff image
            $different_pixels++;
            imagesetpixel($diffi, $x, $y, $green);
        }

    }
}


if (!$different_pixels) {
    echo "Image is the same";
    exit(0);
} else {
    /*if (empty($argv[3])) {
        $argv[3] = 'diffy.png'; // default result filename
    }
    imagepng($diffi, $argv[3]);*/
    $total = $sx1 * $sy1;
    echo "$different_pixels/$total different pixels, or ", number_format(100 * $different_pixels / $total, 2), '%';
    exit(1);
}

//echo "result is $result";

?>