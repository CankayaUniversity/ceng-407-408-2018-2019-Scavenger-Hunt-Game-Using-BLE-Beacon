<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 26.03.2019
 * Time: 14:57
 */
require_once 'Database.php';
$response=array();
$code=$_POST["code"];
$sit=$_POST["situation"];
$userid=$_POST["userid"];
$codesid=null;
$gid=null;
$iid=null;
$isac=1;

function checkplayer(){
    global $con,$userid,$response,$codesid;
    $statement=mysqli_prepare($con,"select * from joingame where codeid=? and userid=? ");
    mysqli_stmt_bind_param($statement,"ii",$codesid,$userid);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);

    $count=mysqli_stmt_num_rows($statement);
    
    if($count>0){
        $response["error"]="you are already in this game";
        $response["success"]=false;
        return false;
    }else{
        return true;
    }
}

function checkcode(){
    global $con,$code,$codesid,$response,$gid;
    $statement=mysqli_prepare($con,"select * from codes where entrycode=?");
    mysqli_stmt_bind_param($statement, "s", $code);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $codeid,$gameid,$entrycode,$starttime,$Startdate,$endtime,$Enddate,$situation);
    $count=mysqli_stmt_num_rows($statement);
    while (mysqli_stmt_fetch($statement)) {
        $codesid=$codeid;
        $gid=$gameid;
    }
    mysqli_stmt_close($statement);
    date_default_timezone_set('Etc/GMT-3');
    $day=date("d");
    $month=date("m");
    $year=date("Y");
    $hour=date("H");
    $minute=date("i");
    $today=new DateTime("$year-$month-$day $hour:$minute:00");

    $edate=date_parse_from_format("j/n/Y",$Enddate);
    $etime=date_parse_from_format("H:iP",$endtime);
    try {
        $enddate = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]:00");
    } catch (Exception $e) {
    }

    if($count>0){

        if($today<$enddate){
            return true;
        }else{
            $response["success"]=false;
            $response["error"]="Code is out of date";
            return false;

        }


    }else{
        $response["success"]=false;
        $response["error"]="Code is invalid";

        return false;
    }
}
function joingame(){
    global $con,$userid,$codesid,$sit;
    $statement=mysqli_prepare($con,"insert into joingame(codeid,userid,situation) values(?,?,?)");
    mysqli_stmt_bind_param($statement,"iii",$codesid,$userid,$sit);
    mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
}
function checkinvited(){
    global $con,$userid,$gid,$iid;
    $statement=mysqli_prepare($con,"select * from invitedplayer where gameid=? and userid=?");
    mysqli_stmt_bind_param($statement, "ii", $gid,$userid);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $invitedid,$gameid,$userid,$isActive);
    $count=mysqli_stmt_num_rows($statement);
    if($count>0){
        while (mysqli_stmt_fetch($statement)) {
            $iid=$invitedid;
        }
        mysqli_stmt_close($statement);
        return true;
    }else{
        mysqli_stmt_close($statement);

        return false;
    }
}
function updateinvited(){
    global $con,$iid,$isac;
    $statement = mysqli_query($con, "UPDATE invitedplayer SET isactive= ".$isac." WHERE invitedid=".$iid." ");
    mysqli_stmt_execute($statement);
}


if(checkcode()){
    if (checkplayer()){
        $response["success"]=true;
        joingame();
        if (checkinvited()){
            updateinvited();
        }
    }
}else{
    $response["success"]=false;

}
echo json_encode($response);

?>