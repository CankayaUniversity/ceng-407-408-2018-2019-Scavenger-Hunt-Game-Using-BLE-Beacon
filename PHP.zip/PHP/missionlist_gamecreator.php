<?php
/**
 * Created by PhpStorm.
 * User: Nuri
 * Date: 28.04.2019
 * Time: 21:10
 */
require_once 'Database.php';
$response=array();
$missions=array();
$count=0;
$gameid=$_POST['gameid'];
date_default_timezone_set('Etc/GMT-3');
$day=date("d");
$month=date("m");
$year=date("Y");
$hour=date("H");
$minute=date("i");
$today=new DateTime("$year-$month-$day $hour:$minute");
$statement=mysqli_prepare($con,"select * from missions where game_id=?");
mysqli_stmt_bind_param($statement,"i",$gameid);
mysqli_stmt_execute($statement);
mysqli_stmt_store_result($statement);
mysqli_stmt_bind_result($statement, $mission_id, $game_id, $mission_name,$mission_description,$mission_type,$mission_starttime,$mission_startdate,$mission_endtime,$mission_enddate,$mission_score,$mission_done,$isautocompare,$samplefoto,$minu,$situation);
while (mysqli_stmt_fetch($statement)) {
    $response[$count]["mission_id"] = $mission_id;
    $response[$count]["mission_name"] = $mission_name;
    $response[$count]["mission_description"] = $mission_description;
    $response[$count]["mission_type"] = $mission_type;
    $response[$count]["mission_starttime"] = $mission_starttime;
    $response[$count]["mission_startdate"] = $mission_startdate;
    $response[$count]["mission_endtime"] = $mission_endtime;
    $response[$count]["mission_enddate"] =$mission_enddate;
    $sdate=date_parse_from_format("j/n/Y",$mission_startdate);
    $edate=date_parse_from_format("j/n/Y",$mission_enddate);
    $stime=date_parse_from_format("H:iP",$mission_starttime);
    $etime=date_parse_from_format("H:iP",$mission_endtime);
    try {
        $enddate = new DateTime("$edate[year]-$edate[month]-$edate[day] $etime[hour]:$etime[minute]");
    } catch (Exception $e) {
    }
    try {
        $startdate = new DateTime("$sdate[year]-$sdate[month]-$sdate[day] $stime[hour]:$stime[minute]");
    } catch (Exception $e) {
    }
    if ($today>$enddate){
        $response[$count]["ismissiononline"]=-1;

    }elseif($startdate>$today){
        $response[$count]["ismissiononline"]=0;
    }else{
        $response[$count]["ismissiononline"]=1;
    }
    $response[$count]["mission_score"] =$mission_score;
    $response[$count]["mission_done"] =$mission_done;
    $response[$count]["isautocompare"] =$isautocompare;
    $response[$count]["samplefoto"] =$samplefoto;
    $response[$count]["minu"] =$minu;
    $response[$count]["situation"] =$situation;
    $count++;
}
$missions["missions"]=$response;
echo json_encode($missions);
?>